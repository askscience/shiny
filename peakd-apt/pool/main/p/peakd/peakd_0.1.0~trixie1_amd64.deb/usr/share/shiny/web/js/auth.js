import { controlButton } from '../ui/components/button.js';
import { apiFetch, setAuth, getToken, clearAuth, logoutSession, validateSession, getTraveler } from './api.js';
import {
  getKnownUsers,
  saveKnownUser,
  renderAvatarEl,
  readAvatarFile,
} from './userProfiles.js';
import { resetUserSession } from './session.js';
import { hideBootScreen } from './bootScreen.js';
import { t } from './i18n.js';

const overlay = document.getElementById('login-overlay');
const appEl = document.getElementById('app');
const errorEl = document.getElementById('login-error');

const stepPick = document.getElementById('login-step-pick');
const stepPassword = document.getElementById('login-step-password');
const stepRegister = document.getElementById('login-step-register');
const profilePicker = document.getElementById('profile-picker');

const passwordInput = document.getElementById('login-password');
const usernameInput = document.getElementById('login-username');
const loginBtn = document.getElementById('login-btn');
const loginBackPick = document.getElementById('login-back-pick');
const registerToLogin = document.getElementById('register-to-login');
const loginToRegister = document.getElementById('login-to-register');
const selectedProfileEl = document.querySelector('#login-step-password .profile-selected');

const registerBackBtn = document.getElementById('login-back-from-register');
const registerBtn = document.getElementById('register-btn');
const registerUsernameInput = document.getElementById('register-username');
const registerPasswordInput = document.getElementById('register-password');
const registerAvatarInput = document.getElementById('register-avatar');
const registerAvatarPreview = document.getElementById('register-avatar-preview');

const selectedAvatarEl = document.getElementById('login-selected-avatar');
const selectedNameEl = document.getElementById('login-selected-name');

let selectedUser = null;
let registerAvatarData = null;
// Linux-user mode: when the server is bound to real Linux accounts, the picker
// lists OS users and self-registration is hidden (Linux is the source of truth).
let linuxMode = false;
// Greeter mode: this very screen is the machine's login. A successful sign-in
// starts that account's own session (see the login handler).
let greeterMode = false;
let linuxUsers = [];

/** Fetch the host's Linux accounts (loopback-only). Silently no-ops otherwise. */
async function loadUnixUsers() {
  try {
    const res = await apiFetch('/api/auth/unix-users', { authRedirect: false });
    linuxMode = !!res?.enabled;
    greeterMode = !!res?.greeter;
    linuxUsers = Array.isArray(res?.users) ? res.users : [];
  } catch {
    linuxMode = false;
    greeterMode = false;
    linuxUsers = [];
  }
}

/** The accounts the picker offers: OS users in Linux mode, saved profiles otherwise. */
function pickerUsers() {
  if (linuxMode) {
    return linuxUsers.map((u) => ({
      id: u.name,
      username: u.name,
      name: u.display_name || u.name,
      avatar: null,
    }));
  }
  return getKnownUsers();
}

function showError(msg) {
  errorEl.classList.remove('is-status');
  errorEl.textContent = msg;
  errorEl.classList.remove('hidden');
}

function hideError() {
  errorEl.classList.remove('is-status');
  errorEl.classList.add('hidden');
}

/**
 * Greeter mode: the password was accepted and that account's session is being
 * started. Freeze the form — the login screen is about to be replaced by the
 * session's kiosk, so there is nothing else to report here.
 */
function showStarting(name) {
  loginBtn?.setAttribute('disabled', '');
  passwordInput?.setAttribute('disabled', '');
  usernameInput?.setAttribute('disabled', '');
  errorEl.classList.add('is-status');
  errorEl.textContent = t('auth.starting', { name }, `Starting ${name}…`);
  errorEl.classList.remove('hidden');
}

/** Undo `showStarting()` when the sign-in failed after all. */
function resetStarting() {
  loginBtn?.removeAttribute('disabled');
  passwordInput?.removeAttribute('disabled');
  usernameInput?.removeAttribute('disabled');
  hideError();
}

function showStep(step) {
  stepPick?.classList.toggle('hidden', step !== 'pick');
  stepPassword?.classList.toggle('hidden', step !== 'password');
  stepRegister?.classList.toggle('hidden', step !== 'register');
  hideError();
}

export function showLogin() {
  hideBootScreen();
  overlay.classList.remove('hidden');
  appEl?.classList.add('hidden');
  selectedUser = null;
  registerAvatarData = null;
  // Resolve the host's Linux accounts first, then render. On a stock install
  // the request returns `enabled:false` and the picker uses saved profiles.
  loadUnixUsers().finally(() => {
    renderProfilePicker();
    if (pickerUsers().length) {
      showStep('pick');
    } else {
      // No profile is known on this device — which is the normal state for a new
      // browser, a private window, or cleared storage. The saved-profile picker
      // would be empty, so go straight to the manual sign-in form: an existing
      // user must be able to type their username, not be forced into "create
      // account" and told their own username is taken.
      showManualLoginStep();
    }
  });
}

export function hideLogin() {
  overlay.classList.add('hidden');
}

function onAuthSuccess(traveler) {
  saveKnownUser(traveler);
  hideLogin();
  appEl?.classList.remove('hidden');
  window.dispatchEvent(new CustomEvent('auth:success'));
}

function renderProfilePicker() {
  if (!profilePicker) return;
  profilePicker.innerHTML = '';

  pickerUsers().forEach((user) => {
    const btn = controlButton();
    btn.type = 'button';
    btn.className = 'profile-tile';
    btn.setAttribute('aria-label', t('auth.signInAs', { name: user.name }, `Sign in as ${user.name}`));

    const avatar = document.createElement('div');
    avatar.className = 'profile-avatar';
    renderAvatarEl(avatar, user);

    const label = document.createElement('span');
    label.className = 'profile-tile-name';
    label.textContent = user.name || user.username;

    btn.append(avatar, label);
    btn.addEventListener('click', () => selectUser(user));
    profilePicker.appendChild(btn);
  });

  // Linux accounts cannot be created from the web — hide "Add user".
  if (linuxMode) return;

  const addBtn = controlButton();
  addBtn.type = 'button';
  addBtn.className = 'profile-tile profile-tile-add';
  addBtn.setAttribute('aria-label', t('auth.addNewUser', null, 'Add new user'));

  const addAvatar = document.createElement('div');
  addAvatar.className = 'profile-avatar profile-avatar-add';
  addAvatar.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';

  const addLabel = document.createElement('span');
  addLabel.className = 'profile-tile-name';
  addLabel.textContent = t('auth.addUser', null, 'Add user');

  addBtn.append(addAvatar, addLabel);
  addBtn.addEventListener('click', () => showRegisterStep());
  profilePicker.appendChild(addBtn);
}

function selectUser(user) {
  selectedUser = user;
  selectedProfileEl?.classList.remove('hidden');
  renderAvatarEl(selectedAvatarEl, user);
  if (selectedNameEl) selectedNameEl.textContent = user.name || user.username;
  // A picked profile already names the user: hide the free-text field so there
  // is exactly one source of truth for the username.
  usernameInput?.classList.add('hidden');
  if (usernameInput) usernameInput.value = '';
  // Back to the picker is meaningful here; "create a profile" is not.
  loginBackPick?.classList.remove('hidden');
  loginToRegister?.classList.add('hidden');
  if (passwordInput) {
    passwordInput.value = '';
    passwordInput.focus();
  }
  showStep('password');
}

/**
 * Sign in by typing a username, for when no profile is saved on this device.
 * The picker step is skipped because it would be empty.
 */
function showManualLoginStep() {
  selectedUser = null;
  // A typed username has no avatar to show; an empty placeholder tile would
  // just add a meaningless "?" above the form.
  selectedProfileEl?.classList.add('hidden');
  // The username field must be *shown*, not merely enabled: `loginBtn` reads
  // it, and a hidden field that is still read would look like a broken login.
  usernameInput?.classList.remove('hidden');
  if (usernameInput) usernameInput.value = '';
  if (passwordInput) passwordInput.value = '';
  // Nothing to go back to, so the Back button would be a dead end; offer the
  // route that helps instead. In Linux mode there is no registration at all.
  loginBackPick?.classList.add('hidden');
  loginToRegister?.classList.toggle('hidden', linuxMode);
  showStep('password');
  (usernameInput || passwordInput)?.focus();
}

function showRegisterStep() {
  // Linux accounts are created in Linux, never here.
  if (linuxMode) {
    showManualLoginStep();
    return;
  }
  selectedUser = null;
  registerAvatarData = null;
  if (registerUsernameInput) registerUsernameInput.value = '';
  if (registerPasswordInput) registerPasswordInput.value = '';
  if (registerAvatarInput) registerAvatarInput.value = '';
  renderAvatarEl(registerAvatarPreview, { name: '', avatar: null });
  registerAvatarPreview?.classList.add('profile-avatar--placeholder');
  showStep('register');
  registerUsernameInput?.focus();
}

loginBackPick?.addEventListener('click', () => {
  selectedUser = null;
  // With no saved profiles there is nothing to go back *to*; the button is
  // hidden in that case (see showManualLoginStep), so this only runs when a
  // picker exists.
  showStep('pick');
});

registerToLogin?.addEventListener('click', () => {
  // "Already have a profile? Sign in" — the escape hatch from the register
  // screen, which is all a first-time visitor on this device used to see.
  if (pickerUsers().length) showStep('pick');
  else showManualLoginStep();
});

loginToRegister?.addEventListener('click', () => showRegisterStep());

registerBackBtn?.addEventListener('click', () => {
  registerAvatarData = null;
  if (pickerUsers().length) showStep('pick');
  else showManualLoginStep();
});

registerAvatarInput?.addEventListener('change', async () => {
  const file = registerAvatarInput.files?.[0];
  if (!file) return;
  try {
    registerAvatarData = await readAvatarFile(file);
    registerAvatarPreview?.classList.remove('profile-avatar--placeholder');
    renderAvatarEl(registerAvatarPreview, { name: registerUsernameInput?.value || '', avatar: registerAvatarData });
  } catch (e) {
    showError(e.message);
    registerAvatarInput.value = '';
  }
});

loginBtn?.addEventListener('click', async () => {
  hideError();

  // Either a picked profile (picker step) or a typed username (manual step).
  const username = selectedUser?.username || usernameInput?.value.trim() || '';
  if (!username) {
    showError(t('auth.enterUsername', null, 'Enter your username'));
    usernameInput?.focus();
    return;
  }
  if (!passwordInput?.value) {
    showError(t('auth.enterPassword', null, 'Enter your password'));
    passwordInput?.focus();
    return;
  }

  try {
    // Greeter mode: show "Starting <user>…" right away. The screen is killed
    // as soon as the new session takes the seat, so the response may never
    // arrive — the optimistic state is the one the user will see.
    if (greeterMode) showStarting(selectedUser?.name || username);
    // `authRedirect: false` — a 401 here means "bad credentials", not an
    // expired session. Without this, apiFetch's global 401 handler fires the
    // misleading "Session expired — sign in again" toast on every wrong password.
    const data = await apiFetch('/api/auth/login', {
      method: 'POST',
      authRedirect: false,
      body: JSON.stringify({
        username,
        password: passwordInput.value,
      }),
    });
    // Greeter mode: no token comes back — the server verified the password and
    // started that account's own session.
    if (data?.session_starting) {
      showStarting(data.display_name || data.user || username);
      return;
    }
    setAuth(data.token, data.traveler);
    onAuthSuccess(data.traveler);
  } catch (e) {
    if (greeterMode) resetStarting();
    showError(e.message);
  }
});

passwordInput?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') loginBtn?.click();
});

usernameInput?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') passwordInput?.focus();
});

registerBtn?.addEventListener('click', async () => {
  hideError();
  const username = registerUsernameInput?.value.trim() || '';
  const password = registerPasswordInput?.value || '';

  if (!username) {
    showError(t('auth.chooseUsername', null, 'Choose a username'));
    registerUsernameInput?.focus();
    return;
  }
  if (!password) {
    showError(t('auth.choosePassword', null, 'Choose a password'));
    registerPasswordInput?.focus();
    return;
  }

  try {
    const data = await apiFetch('/api/auth/register', {
      method: 'POST',
      authRedirect: false,
      body: JSON.stringify({
        username,
        password,
        avatar: registerAvatarData,
      }),
    });
    setAuth(data.token, data.traveler);
    onAuthSuccess(data.traveler);
  } catch (e) {
    showError(e.message);
  }
});

export async function logout() {
  // Invalidate the session server-side + clear the HttpOnly cookie first.
  await logoutSession();
  resetUserSession();
  // In the kiosk the machine's login screen is the greeter, not this overlay:
  // ask the shell to sign out (it exits with the sign-out status and the
  // session supervisor hands the seat back to the greeter). A plain browser
  // has no IPC bridge and keeps the in-app login screen.
  if (window.ipc?.postMessage) {
    window.ipc.postMessage('peakd:logout');
    return;
  }
  appEl?.classList.add('hidden');
  showLogin();
}

export async function requireAuth() {
  // validateSession() also checks the `shiny_token` session cookie, so don't
  // bail out early just because localStorage has no token.
  const valid = await validateSession();
  if (!valid) {
    clearAuth();
    showLogin();
    return false;
  }
  const traveler = getTraveler();
  if (traveler) saveKnownUser(traveler);
  return true;
}

window.addEventListener('auth:expired', () => {
  resetUserSession();
  clearAuth();
  showLogin();
  window.dispatchEvent(new CustomEvent('app:toast', {
    detail: { message: t('auth.sessionExpired', null, 'Session expired — sign in again'), type: 'error' },
  }));
});

export { clearAuth, getToken };
