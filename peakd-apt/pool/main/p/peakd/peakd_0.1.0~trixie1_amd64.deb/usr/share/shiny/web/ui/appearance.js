/**
 * appearance — the accent / gradient engine.
 *
 * The UI is monochrome; the user picks ONE accent color and ONE gradient
 * (presets from the active theme manifest, or custom). This module derives
 * every accent-related token (--accent-soft, --gradient-mesh, …) and
 * broadcasts `appearance:change` so JS-rendered surfaces (map, tiles, the
 * voice bar's glow) can follow. A legacy `accent:change` event is also dispatched.
 *
 * Storage is per user; the app injects its scope via initAppearance:
 *   initAppearance({ getScope: () => getTraveler()?.id })
 */

import { getThemeManifest, themeMode } from './theme-loader.js';

const ACCENT_KEY = 'ui.accent';
const GRADIENT_KEY = 'ui.gradient';
const DEFAULT_ACCENT = '#7fa8e8';
const DEFAULT_GRADIENT = { id: 'mono', angle: 135, stops: ['#e8eaed', '#6b7078'] };

let getScope = () => null;

function scopedKey(base) {
  const id = getScope();
  return id ? `${base}.${id}` : base;
}

/* ── color math ─────────────────────────────────────────────── */

export function hexToRgb(hex) {
  const h = String(hex || '').replace('#', '');
  const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h;
  const n = parseInt(full, 16);
  if (Number.isNaN(n)) return [255, 255, 255];
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgba(hex, alpha) {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

/** Readable text color (near-black or near-white) for a given background. */
export function contrastFor(hex) {
  const [r, g, b] = hexToRgb(hex);
  const luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return luminance > 0.6 ? '#0a0a0a' : '#fafafa';
}

/** Perceived brightness of a hex colour, 0 (black) … 1 (white). */
function luminance(hex) {
  const [r, g, b] = hexToRgb(hex);
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

/* The accent is stored per user, not per theme, and it is used as INK
 * (`color: var(--accent)` labels, icons, active states) as well as fill. A
 * colour picked on the other side of the light/dark divide — near-white chosen
 * in a dark theme, then a light theme activated — would render that ink
 * invisible on the canvas, so it falls back to the theme's own default. The
 * stored choice is kept, so returning to the other theme restores it. */
const LIGHT_CANVAS_MAX_INK = 0.75;
const DARK_CANVAS_MIN_INK = 0.18;

function usableAccent(accent) {
  const mode = themeMode();
  if (!mode) return accent; // theme not resolved yet — keep the colour as-is
  const lum = luminance(accent);
  const invisible = mode === 'light'
    ? lum > LIGHT_CANVAS_MAX_INK
    : lum < DARK_CANVAS_MIN_INK;
  if (!invisible) return accent;
  return getThemeManifest()?.defaultAccent || DEFAULT_ACCENT;
}

/** Current computed value of a CSS variable on :root (for canvas/JS rendering). */
export function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

/* ── stored state ───────────────────────────────────────────── */

/** The accent in effect: the stored choice when it can be seen on this theme's
 *  canvas, otherwise the theme's own default. */
export function getAccent() {
  const stored = localStorage.getItem(scopedKey(ACCENT_KEY));
  const base = stored || getThemeManifest()?.defaultAccent || DEFAULT_ACCENT;
  return usableAccent(base);
}

export function setAccent(hex) {
  localStorage.setItem(scopedKey(ACCENT_KEY), hex);
}

export function getGradient() {
  try {
    const raw = localStorage.getItem(scopedKey(GRADIENT_KEY));
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.stops) && parsed.stops.length >= 2) return parsed;
    }
  } catch (_) { /* fall through */ }
  // A theme declares its default gradient by id (theme.json → defaultGradient).
  const manifest = getThemeManifest();
  const id = manifest?.defaultGradient;
  const preset = (manifest?.gradients || []).find((g) => g.id === id);
  return preset ? { id: preset.id, angle: preset.angle, stops: preset.stops } : DEFAULT_GRADIENT;
}

export function setGradient(gradient) {
  localStorage.setItem(scopedKey(GRADIENT_KEY), JSON.stringify(gradient));
}

/* ── global font ──────────────────────────────────────────────
 * One UI-wide typeface, independent of the theme's own `--font-*` tokens.
 * `'theme'` leaves the theme in charge; any other value is a family name from
 * the host's fontconfig (see GET /api/fonts + web/js/fonts.js) and overrides
 * `--font-body` and `--font-display`. `--font-editorial` is deliberately left
 * alone — it is a display accent (the Writer's face), not body type.
 * ─────────────────────────────────────────────────────────────── */

const FONT_KEY = 'ui.font';
const DEFAULT_FONT = 'Roboto';

/** Sentinel: follow the active theme's own fonts instead of an override. */
export const FONT_THEME = 'theme';

/** The chosen global font family (defaults to the system UI font). */
export function getFont() {
  return localStorage.getItem(scopedKey(FONT_KEY)) || DEFAULT_FONT;
}

/** A CSS stack for a family name, with a generic fallback. `null` for theme. */
export function fontStackFor(family) {
  const name = String(family || '').trim();
  if (!name || name === FONT_THEME) return null;
  if (name === 'system-ui') return 'system-ui, -apple-system, sans-serif';
  const safe = name.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  const serif = /serif$/i.test(name) && !/sans[- ]?serif$/i.test(name);
  return `"${safe}", ${serif ? 'serif' : 'sans-serif'}`;
}

export function setFont(value) {
  const v = String(value || '').trim() || DEFAULT_FONT;
  localStorage.setItem(scopedKey(FONT_KEY), v);
  applyFont();
}

/** Gradient presets declared by the active theme. */
export function gradientPresets() {
  return getThemeManifest()?.gradients || [];
}

export function accentPresets() {
  return getThemeManifest()?.accents || [];
}

/* ── application ────────────────────────────────────────────── */

export function gradientToCss(gradient) {
  const angle = Number.isFinite(gradient?.angle) ? gradient.angle : 135;
  const stops = gradient?.stops?.length >= 2 ? gradient.stops : DEFAULT_GRADIENT.stops;
  return `linear-gradient(${angle}deg, ${stops.join(', ')})`;
}

export function applyAppearance({ accent = getAccent(), gradient = getGradient() } = {}) {
  const root = document.documentElement;
  const stops = gradient?.stops?.length >= 2 ? gradient.stops : DEFAULT_GRADIENT.stops;
  const tail = stops[stops.length - 1];

  root.style.setProperty('--accent', accent);
  root.style.setProperty('--accent-2', tail);
  root.style.setProperty('--accent-soft', rgba(accent, 0.1));
  root.style.setProperty('--accent-glow', rgba(accent, 0.24));
  root.style.setProperty('--accent-contrast', contrastFor(accent));
  root.style.setProperty('--gradient-accent', gradientToCss(gradient));
  root.style.setProperty('--gradient-text',
    `linear-gradient(120deg, var(--text) 0%, ${stops[0]} 45%, ${tail} 100%)`);
  // Ambient background mesh — an accent presence, still quiet, but now
  // visible enough to give the surface a soft glow (not just a whisper).
  root.style.setProperty('--gradient-mesh',
    `radial-gradient(ellipse 80% 60% at 20% 10%, ${rgba(stops[0], 0.13)} 0%, transparent 55%),` +
    `radial-gradient(ellipse 70% 50% at 80% 90%, ${rgba(tail, 0.1)} 0%, transparent 50%)`);

  applyFocusSpectrum(root, accent);

  applyFont();

  const detail = { accent, gradient };
  window.dispatchEvent(new CustomEvent('appearance:change', { detail }));
  window.dispatchEvent(new CustomEvent('accent:change', { detail: { accent } })); // legacy
}

/**
 * Focus mode paints the *whole* accent palette of the theme — not just the
 * accent the user picked — so a focused window is unmistakable. Two variables
 * carry it: `--focus-ring`, the window frame (a conic wheel, because a frame is
 * a contour: it starts at the **bottom-left** corner and runs clockwise, and
 * blends colour into colour rather than banding them), and `--focus-bar`, the
 * same palette laid out straight for the tray underline. The chosen accent leads
 * the wheel so the user's own colour is still part of it.
 *
 * Deliberately plain: the stops are literal angles and the wheel closes on its
 * first colour, so nothing here depends on a `calc()` over an animated custom
 * property. A frame whose background fails to parse is not a subtly wrong frame
 * — it is no frame at all (measured: the animated-`calc()` version drew nothing).
 */
function applyFocusSpectrum(root, accent) {
  const seen = new Set([String(accent).toLowerCase()]);
  const palette = [accent];
  for (const preset of accentPresets()) {
    const value = String(preset?.value || '').trim();
    if (!/^#[0-9a-f]{3,8}$/i.test(value) || seen.has(value.toLowerCase())) continue;
    seen.add(value.toLowerCase());
    palette.push(value);
  }
  if (palette.length < 2) return; // a theme with a single accent: keep --accent

  const step = 360 / palette.length;
  const stops = palette.map((c, i) => `${c} ${(i * step).toFixed(2)}deg`).join(', ');
  const from = 225; // the bottom-left diagonal: 0deg is up, clockwise
  root.style.setProperty('--focus-ring',
    `conic-gradient(from ${from}deg, ${stops}, ${palette[0]} 360deg)`);
  root.style.setProperty('--focus-bar', `linear-gradient(90deg, ${palette.join(', ')})`);
}

/** Write the global font onto :root, or clear the override for 'theme'. */
export function applyFont() {
  const root = document.documentElement;
  const stack = fontStackFor(getFont());
  if (!stack) {
    root.style.removeProperty('--font-body');
    root.style.removeProperty('--font-display');
  } else {
    root.style.setProperty('--font-body', stack);
    root.style.setProperty('--font-display', stack);
  }
}

/** Boot: wire per-user scoping and apply the stored appearance. */
export function initAppearance({ getScope: scopeGetter } = {}) {
  if (typeof scopeGetter === 'function') getScope = scopeGetter;
  applyAppearance();
  // A theme switch changes the canvas. `setTheme()` updates the manifest before
  // dispatching, so `themeMode()` is already correct here — this recomputes the
  // accent (a near-white accent picked in a dark theme must fall back on a light
  // canvas), `--accent-contrast`, and the gradients. Without it the old theme's
  // accent lingers as ink and accent-coloured icons/labels go invisible.
  window.addEventListener('theme:change', () => applyAppearance());
}

/** Re-apply after login / user switch (scope changed). */
export function refreshAppearance() {
  applyAppearance();
}
