import { apiFetch, getTraveler } from './api.js';

const cache = new Map();
let summaries = [];

function dockStorageKey() {
  const id = getTraveler()?.id;
  return id ? `dock.destination.${id}` : 'dock.destination';
}

function readActiveDestination() {
  return localStorage.getItem(dockStorageKey()) || '';
}

let activeDestinationKey = readActiveDestination();

/** At most one saved card per topic for a destination. */
const DOCK_TOPIC_SLOTS = ['overview', 'food', 'culture', 'nightlife'];

export function topicSlotForSummary(s) {
  if (!s) return 'other';
  const type = s.type || s.artifact_type || '';
  if (type === 'travel_plan' || s.theme === 'overview') return 'overview';
  if (s.theme && DOCK_TOPIC_SLOTS.includes(s.theme)) return s.theme;
  return `other:${type}`;
}

function sortDockSummaries(list) {
  const slotOrder = (s) => {
    const slot = topicSlotForSummary(s);
    const i = DOCK_TOPIC_SLOTS.indexOf(slot);
    return i >= 0 ? i : DOCK_TOPIC_SLOTS.length;
  };
  return [...list].sort(
    (a, b) => slotOrder(a) - slotOrder(b) || (b.updated_at || '').localeCompare(a.updated_at || ''),
  );
}

export function normalizeDestinationKey(value) {
  if (!value) return '';
  return String(value)
    .toLowerCase()
    .replace(/^trip to\s+/i, '')
    .trim();
}

export function destinationKeyForSummary(s) {
  if (!s) return '';
  if (s.destination) return normalizeDestinationKey(s.destination);
  if (s.theme && s.subtitle) return normalizeDestinationKey(s.subtitle);
  if ((s.type || s.artifact_type) === 'travel_plan') {
    return normalizeDestinationKey(s.title);
  }
  return '';
}

export function destinationKeyForArtifact(artifact) {
  if (!artifact) return '';
  if (artifact.destination) return normalizeDestinationKey(artifact.destination);
  if (artifact.theme && artifact.subtitle) return normalizeDestinationKey(artifact.subtitle);
  if (artifact.type === 'travel_plan') return normalizeDestinationKey(artifact.title);
  return '';
}

export function getActiveDestination() {
  return activeDestinationKey;
}

export function setActiveDestination(key) {
  activeDestinationKey = normalizeDestinationKey(key);
  const storageKey = dockStorageKey();
  if (activeDestinationKey) {
    localStorage.setItem(storageKey, activeDestinationKey);
  } else {
    localStorage.removeItem(storageKey);
  }
  window.dispatchEvent(new CustomEvent('artifact:dock', { detail: getDockSummaries() }));
}

/** Keep only guides for the active city; replace prior cards for that city with this batch. */
export function applyDockDestinationGroup(destinationKey, artifactIds = []) {
  const key = normalizeDestinationKey(destinationKey);
  if (!key) return;
  activeDestinationKey = key;
  localStorage.setItem(dockStorageKey(), key);
  const idSet = new Set(artifactIds);
  summaries = summaries.filter((s) => {
    const sKey = destinationKeyForSummary(s);
    if (sKey !== key) return true;
    return idSet.has(s.id);
  });
  summaries = dedupeSummaries(summaries);
  window.dispatchEvent(new CustomEvent('artifact:dock', { detail: getDockSummaries() }));
}

/**
 * Artifact types the traveler plugin owns.
 *
 * Needed because artifacts saved before plugins started stamping their owner
 * have no `plugin` field at all — 103 of them in the live database — and those
 * are traveler guides. Without this they would vanish from the dock entirely.
 */
const TRAVELER_TYPES = new Set([
  'travel_plan',
  'tour_plan',
  'route_preview',
  'poi_list',
  'monument_info',
  'site_info',
]);

/**
 * Whether `summary` was produced by `pluginName`.
 *
 * A card belongs to the window it came from, and only that window's dock may
 * draw it. Untagged legacy cards count as the traveler's, since nothing else
 * existed when they were written; `site_info` is the one type core still emits,
 * and a core card has no window of its own to live in.
 */
export function artifactBelongsTo(summary, pluginName) {
  if (!summary || !pluginName) return false;
  const owner = summary.plugin;
  if (!owner) return pluginName === 'traveler' && TRAVELER_TYPES.has(summary.type);
  return owner === pluginName;
}

/**
 * The cards one window's dock should draw.
 *
 * `pluginName` scopes the result to that window's own cards, and skips the
 * traveler's grouping rules along with it: "the active destination" and the
 * guide topic slots (overview/food/culture/nightlife) are traveler concepts,
 * and applying them to another window would both hide its cards and let the
 * traveler's current city decide what the browser shows.
 *
 * Omit `pluginName` for the unscoped chrome dock (chat-only mode), where the
 * destination grouping is what makes the dock useful.
 */
export function getDockSummaries(pluginName) {
  if (pluginName) {
    const scoped = summaries.filter((s) => artifactBelongsTo(s, pluginName));
    return sortDockSummaries(dedupeSummaries(scoped)).slice(0, 4);
  }
  const pool = activeDestinationKey
    ? summaries.filter((s) => destinationKeyForSummary(s) === activeDestinationKey)
    : summaries;
  const deduped = dedupeSummaries(pool);
  const topical = sortDockSummaries(
    deduped.filter((s) => DOCK_TOPIC_SLOTS.includes(topicSlotForSummary(s))),
  );
  if (topical.length) return topical.slice(0, DOCK_TOPIC_SLOTS.length);
  return sortDockSummaries(deduped).slice(0, 4);
}

function pickDefaultDestination(list) {
  const plan = list.find((s) => (s.type || s.artifact_type) === 'travel_plan');
  if (plan) return destinationKeyForSummary(plan);
  return destinationKeyForSummary(list[0]);
}

export function normalizeArtifact(raw) {
  if (!raw) return raw;
  const type = raw.type || raw.artifact_type || 'site_info';
  return {
    ...raw,
    type,
    theme: raw.theme || null,
    destination: raw.destination || null,
    narrative: raw.narrative || null,
    days: raw.days || [],
    geometry: raw.geometry || [],
    route: raw.route || null,
    sections: raw.sections || [],
    actions: raw.actions || [],
    coordinates: raw.coordinates || null,
  };
}

function dedupeSummaries(list) {
  const byId = new Map();
  for (const s of list) {
    const existing = byId.get(s.id);
    if (!existing || (s.updated_at || '') > (existing.updated_at || '')) {
      byId.set(s.id, s);
    }
  }
  const byTopic = new Map();
  for (const s of byId.values()) {
    const dest = destinationKeyForSummary(s);
    const key = `${dest}:${topicSlotForSummary(s)}`;
    const prev = byTopic.get(key);
    if (!prev || (s.updated_at || '') > (prev.updated_at || '')) {
      byTopic.set(key, s);
    }
  }
  return [...byTopic.values()]
    .map((s) => ({ ...s, type: s.type || s.artifact_type || 'site_info' }));
}

export function getSummaries() {
  return summaries;
}

/** Display name for a saved destination chip (city the user asked for). */
export function destinationLabel(summary) {
  if (!summary) return '';
  if (summary.destination) return formatPlaceName(summary.destination);
  if ((summary.type || summary.artifact_type) === 'travel_plan') {
    return formatPlaceName(summary.title);
  }
  if (summary.subtitle) return formatPlaceName(summary.subtitle);
  return formatPlaceName(summary.title);
}

function formatPlaceName(raw) {
  if (!raw) return '';
  return String(raw)
    .replace(/^trip to\s+/i, '')
    .replace(/\s+travel plan$/i, '')
    .trim();
}

function summaryPriority(s) {
  const type = s.type || s.artifact_type || '';
  if (type === 'travel_plan') return 3;
  if (s.theme === 'overview') return 2;
  return 1;
}

/**
 * Unique saved destinations for the left HUD (one chip per city).
 *
 * Scoped to the traveler's own cards: "saved places" is a traveler concept, and
 * another plugin's card that happens to carry a destination should not appear in
 * the places menu.
 *
 * @returns {{ key: string, label: string, artifactId: string }[]}
 */
export function getSavedDestinations() {
  const entries = new Map();
  for (const s of summaries) {
    if (!artifactBelongsTo(s, 'traveler')) continue;
    const key = destinationKeyForSummary(s);
    if (!key) continue;
    const label = destinationLabel(s);
    if (!label) continue;
    const score = summaryPriority(s);
    const prev = entries.get(key);
    if (!prev || score > prev.score || (s.updated_at || '') > (prev.updated_at || '')) {
      entries.set(key, {
        key,
        label,
        artifactId: s.id,
        score,
        updated_at: s.updated_at || '',
      });
    }
  }
  return [...entries.values()]
    .sort((a, b) => (b.updated_at || '').localeCompare(a.updated_at || ''))
    .map(({ key, label, artifactId }) => ({ key, label, artifactId }));
}

export function getCachedArtifact(id) {
  return cache.get(id) || null;
}

export function cacheArtifactLocal(artifact) {
  const normalized = normalizeArtifact(artifact);
  cache.set(normalized.id, normalized);
  return normalized;
}

export function removeSummary(id) {
  summaries = summaries.filter((s) => s.id !== id);
  cache.delete(id);
  window.dispatchEvent(new CustomEvent('artifact:dock', { detail: getDockSummaries() }));
}

export async function loadArtifacts() {
  activeDestinationKey = readActiveDestination();
  try {
    const res = await apiFetch('/api/artifacts');
    summaries = dedupeSummaries(res.data || []);
    if (!activeDestinationKey) {
      const def = pickDefaultDestination(summaries);
      if (def) activeDestinationKey = def;
    }
    const dock = getDockSummaries();
    await Promise.all(
      dock.map(async (s) => {
        try {
          await getArtifact(s.id);
        } catch (_) {
          /* keep summary; open will retry */
        }
      })
    );
    window.dispatchEvent(new CustomEvent('artifact:dock', { detail: dock }));
    return dock;
  } catch (e) {
    if (e.status !== 401) {
      console.warn('Failed to load artifacts:', e);
    }
    summaries = [];
    window.dispatchEvent(new CustomEvent('artifact:dock', { detail: [] }));
    return [];
  }
}

export async function upsertArtifact(artifact, tripId = null) {
  const normalized = normalizeArtifact(artifact);
  try {
    const res = await apiFetch('/api/artifacts', {
      method: 'POST',
      body: JSON.stringify({ artifact: normalized, trip_id: tripId }),
    });
    const saved = normalizeArtifact(res.data);
    cache.set(saved.id, saved);
    const summary = {
      id: saved.id,
      type: saved.type,
      title: saved.title,
      theme: saved.theme || null,
      destination: saved.destination || null,
      subtitle: saved.subtitle || null,
      plugin: normalized.plugin || null,
      updated_at: new Date().toISOString(),
    };
    const idx = summaries.findIndex((s) => s.id === saved.id);
    if (idx >= 0) {
      summaries[idx] = summary;
      window.dispatchEvent(new CustomEvent('artifact:updated', { detail: saved }));
    } else {
      summaries.unshift(summary);
      window.dispatchEvent(new CustomEvent('artifact:saved', { detail: saved }));
    }
    summaries = dedupeSummaries(summaries);
    window.dispatchEvent(new CustomEvent('artifact:dock', { detail: getDockSummaries() }));
    return saved;
  } catch (e) {
    if (e.status !== 401) {
      console.warn('Failed to save artifact:', e);
    }
    cache.set(normalized.id, normalized);
    const summary = {
      id: normalized.id,
      type: normalized.type,
      title: normalized.title,
      theme: normalized.theme || null,
      destination: normalized.destination || null,
      subtitle: normalized.subtitle || null,
      plugin: normalized.plugin || null,
      updated_at: new Date().toISOString(),
    };
    if (!summaries.some((s) => s.id === normalized.id)) {
      summaries.unshift(summary);
      summaries = dedupeSummaries(summaries);
      window.dispatchEvent(new CustomEvent('artifact:dock', { detail: getDockSummaries() }));
    }
    return normalized;
  }
}

export function resetArtifactStore() {
  cache.clear();
  summaries = [];
  activeDestinationKey = '';
  window.dispatchEvent(new CustomEvent('artifact:dock', { detail: [] }));
  window.dispatchEvent(new CustomEvent('artifact:clear'));
}

export async function getArtifact(id) {
  if (cache.has(id)) return normalizeArtifact(cache.get(id));
  const res = await apiFetch(`/api/artifacts/${id}`);
  const artifact = normalizeArtifact(res.data);
  cache.set(id, artifact);
  return artifact;
}
