# PEAK'D!

Application payload for PEAK'D! (`peakd` shell plus the `shiny` server and
plugins). The package intentionally contains no user database, API endpoints,
model weights, Tailscale state or live-only installer configuration.
