import { apiFetch, getTraveler } from './api.js';
import { isMobilePortrait } from './viewport.js';
import { normalizeTouchBarSetting } from './touchbarShared.js';
import { DEFAULT_HUD_CHIPS, normalizeHudChips, hudChipsDataset } from './hudChipsShared.js';
import { effectivePowerMode, normalizePowerMode } from './powerShared.js';
import { voiceForEngine } from './voiceShared.js';
import { getLocalePreference, setLocalePreference, refreshLocaleFromStorage } from './i18n.js';

const AI_NAME_KEY = 'ai.name';
const AI_PROVIDER_KEY = 'ai.provider';
const AI_THINK_KEY = 'ai.think';
const OLLAMA_MODEL_KEY = 'ai.ollama_model';
const OPENAI_BASE_URL_KEY = 'ai.openai_base_url';
const OPENAI_API_KEY_KEY = 'ai.openai_api_key';
const OPENAI_MODEL_KEY = 'ai.openai_model';
const PLUGIN_LAYOUT_KEY = 'plugin.layout';
const LINK_PLUGIN_KEY = 'link.plugin';
const DESKTOP_WORKSPACES_KEY = 'desktop.workspaces';
const DESKTOP_ACTIVE_KEY = 'desktop.active';
const DESKTOP_FOCUS_KEY = 'desktop.plugin_focus';
const DESKTOP_LAYOUT_KEY = 'desktop.layout';
const DESKTOP_WINDOWS_KEY = 'desktop.windows';
const DESKTOP_REMEMBER_KEY = 'session.remember';
const DESKTOP_SURFACE_KEY = 'desktop.surface';
const VOICE_TTS_VOICE_KEY = 'voice.tts_voice';        // Supertonic voice
const VOICE_QWEN_VOICE_KEY = 'voice.qwen_voice';      // Qwen3-TTS speaker
const VOICE_TTS_SPEED_KEY = 'voice.tts_speed';
const VOICE_SILENCE_KEY = 'voice.silence_timeout';
const VOICE_WAKE_KEY = 'voice.wake_word';
const VOICE_CONVERSATION_KEY = 'voice.conversation';
const VOICE_CONVERSATION_TIMEOUT_KEY = 'voice.conversation_timeout';
const VOICE_STT_ENGINE_KEY = 'voice.stt_engine';
const VOICE_WHISPER_MODEL_KEY = 'voice.whisper_model';
const VOICE_TTS_ENGINE_KEY = 'voice.tts_engine';
const VOICE_QWEN_MODEL_KEY = 'voice.qwen_model';
const IMAGE_MODEL_KEY = 'image.model';
const IMAGE_QUALITY_KEY = 'image.quality';
const MUSIC_QUALITY_KEY = 'music.quality';
const TOUCHBAR_KEY = 'touchbar.enabled';
const UI_LOCALE_KEY = 'ui.locale';
const STORE_AUTO_UPDATE_KEY = 'store.autoUpdate';
const DEFAULT_AI_NAME = 'Peak';

function scopedKey(base) {
  const id = getTraveler()?.id;
  return id ? `${base}.${id}` : base;
}

/* ── Server persistence ────────────────────────────────────────
 * Preferences are the user's own space in the DATABASE. localStorage is only
 * a synchronous cache; every write is also flushed (debounced) to
 * /api/preferences, which stores rows keyed by (user_id, key).
 * ─────────────────────────────────────────────────────────────── */

let dirty = new Map();
let flushTimer = null;

function persist(base, rawValue) {
  dirty.set(base, rawValue);
  if (flushTimer) clearTimeout(flushTimer);
  flushTimer = setTimeout(flushPreferences, 400);
}

async function flushPreferences() {
  flushTimer = null;
  if (!dirty.size) return;
  const payload = {};
  for (const [k, v] of dirty) payload[k] = v;
  dirty = new Map();
  try {
    await apiFetch('/api/preferences', {
      method: 'PUT',
      authRedirect: false,
      body: JSON.stringify(payload),
    });
  } catch (_) {
    // Transient failure: put the keys back so the next change re-flushes
    // them (they used to be silently dropped).
    for (const [k, v] of Object.entries(payload)) {
      if (!dirty.has(k)) dirty.set(k, v);
    }
  }
}

/** Force an immediate flush (e.g. before navigating away on "Done"). */
export function flushPreferencesNow() {
  if (flushTimer) {
    clearTimeout(flushTimer);
    flushTimer = null;
  }
  return flushPreferences();
}

/** Load this user's saved preferences from the database into the local cache. */
export async function loadUserPreferences() {
  const id = getTraveler()?.id;
  if (!id) return;
  try {
    const res = await apiFetch('/api/preferences', { authRedirect: false });
    const data = res?.data || {};
    for (const [base, value] of Object.entries(data)) {
      localStorage.setItem(`${base}.${id}`, value);
    }
  } catch (_) {
    // Keep the existing local cache when the server is unreachable.
  }
  applyDesktopSurface();
  applyDesktopGap();
  applyImmersive();
  applyHudChips();
  // The interface language may have just arrived from the server; re-apply it
  // (i18n.js owns the value, this is only the persistence side of it).
  await refreshLocaleFromStorage();
}

export function getAiName() {
  return localStorage.getItem(scopedKey(AI_NAME_KEY)) || DEFAULT_AI_NAME;
}

export function setAiName(name) {
  const trimmed = (name || '').trim();
  const key = scopedKey(AI_NAME_KEY);
  if (trimmed) localStorage.setItem(key, trimmed);
  else localStorage.removeItem(key);
  persist(AI_NAME_KEY, trimmed);
}

export function getOllamaModel() {
  return localStorage.getItem(scopedKey(OLLAMA_MODEL_KEY)) || '';
}

export function setOllamaModel(model) {
  const trimmed = (model || '').trim();
  const key = scopedKey(OLLAMA_MODEL_KEY);
  if (trimmed) localStorage.setItem(key, trimmed);
  else localStorage.removeItem(key);
  persist(OLLAMA_MODEL_KEY, trimmed);
  // The thinking capability is per model — every surface that shows the
  // brain toggle re-resolves it against the new one.
  window.dispatchEvent(new CustomEvent('ai:settings'));
}

/**
 * Thinking mode (Ollama thinking models): let the model emit its reasoning
 * trace. ON by default — that is what the model does anyway; the toggle
 * exists to turn it OFF for faster answers. Only ever sent when the model
 * actually supports it (GET /api/ai/thinking gates the button).
 */
export function getThink() {
  return localStorage.getItem(scopedKey(AI_THINK_KEY)) !== 'false';
}

export function setThink(on) {
  const key = scopedKey(AI_THINK_KEY);
  const value = on ? 'true' : 'false';
  localStorage.setItem(key, value);
  persist(AI_THINK_KEY, value);
  window.dispatchEvent(new CustomEvent('ai:settings'));
}

/** Which AI provider answers the assistant: 'ollama' (default) or 'openai'. */
export function getAiProvider() {
  return localStorage.getItem(scopedKey(AI_PROVIDER_KEY)) || 'ollama';
}

export function setAiProvider(provider) {
  const trimmed = (provider || 'ollama').trim();
  const key = scopedKey(AI_PROVIDER_KEY);
  if (trimmed && trimmed !== 'ollama') localStorage.setItem(key, trimmed);
  else localStorage.removeItem(key);
  persist(AI_PROVIDER_KEY, trimmed === 'ollama' ? '' : trimmed);
  // Only Ollama exposes the thinking capability.
  window.dispatchEvent(new CustomEvent('ai:settings'));
}

export function getOpenAiBaseUrl() {
  return localStorage.getItem(scopedKey(OPENAI_BASE_URL_KEY)) || '';
}

export function setOpenAiBaseUrl(url) {
  const trimmed = (url || '').trim();
  const key = scopedKey(OPENAI_BASE_URL_KEY);
  if (trimmed) localStorage.setItem(key, trimmed);
  else localStorage.removeItem(key);
  persist(OPENAI_BASE_URL_KEY, trimmed);
}

export function getOpenAiApiKey() {
  return localStorage.getItem(scopedKey(OPENAI_API_KEY_KEY)) || '';
}

export function setOpenAiApiKey(keyValue) {
  const trimmed = (keyValue || '').trim();
  const key = scopedKey(OPENAI_API_KEY_KEY);
  if (trimmed) localStorage.setItem(key, trimmed);
  else localStorage.removeItem(key);
  persist(OPENAI_API_KEY_KEY, trimmed);
}

export function getOpenAiModel() {
  return localStorage.getItem(scopedKey(OPENAI_MODEL_KEY)) || '';
}

export function setOpenAiModel(model) {
  const trimmed = (model || '').trim();
  const key = scopedKey(OPENAI_MODEL_KEY);
  if (trimmed) localStorage.setItem(key, trimmed);
  else localStorage.removeItem(key);
  persist(OPENAI_MODEL_KEY, trimmed);
}

/**
 * "Remember my workspace" — controls only whether the desktop window
 * arrangement (workspaces, layout, fullscreen) is restored at sign-in. When
 * off, a sign-in starts with a clean desktop; plugin activation and chat are
 * the user's own and persist regardless of this switch.
 */
export function getRemember() {
  return localStorage.getItem(scopedKey(DESKTOP_REMEMBER_KEY)) === 'true';
}

export function setRemember(on) {
  const key = scopedKey(DESKTOP_REMEMBER_KEY);
  if (on) localStorage.setItem(key, 'true');
  else localStorage.removeItem(key);
  persist(DESKTOP_REMEMBER_KEY, on ? 'true' : '');
}

/**
 * Per-plugin window mode: 'tile' (right-rail tile) or 'full' (overlay
 * takeover). Stored per traveler, default 'tile'.
 */
export function getPluginLayout(name) {
  return localStorage.getItem(scopedKey(`${PLUGIN_LAYOUT_KEY}.${name}`)) || 'tile';
}

export function setPluginLayout(name, mode) {
  const key = scopedKey(`${PLUGIN_LAYOUT_KEY}.${name}`);
  if (mode === 'full') localStorage.setItem(key, 'full');
  else localStorage.removeItem(key);
  persist(`${PLUGIN_LAYOUT_KEY}.${name}`, mode === 'full' ? 'full' : '');
}

/**
 * Whether the Craft store updates the apps it installed on its own. Default
 * on: an installed app is a static site the store can replace safely, and a
 * stale app is the thing users notice.
 */
export function getStoreAutoUpdate() {
  return localStorage.getItem(scopedKey(STORE_AUTO_UPDATE_KEY)) !== 'false';
}

export function setStoreAutoUpdate(on) {
  const key = scopedKey(STORE_AUTO_UPDATE_KEY);
  if (on) localStorage.removeItem(key); // default true
  else localStorage.setItem(key, 'false');
  persist(STORE_AUTO_UPDATE_KEY, on ? 'true' : 'false');
}

/**
 * Which plugin opens links clicked anywhere in the kiosk: the `browser` plugin
 * (default) or another installed plugin declaring the `open-urls` capability.
 * Resolved at click time, so a change applies with the next link.
 */
export function getLinkPlugin() {
  return localStorage.getItem(scopedKey(LINK_PLUGIN_KEY)) || 'browser';
}

export function setLinkPlugin(name) {
  const trimmed = (name || 'browser').trim() || 'browser';
  const key = scopedKey(LINK_PLUGIN_KEY);
  if (trimmed !== 'browser') localStorage.setItem(key, trimmed);
  else localStorage.removeItem(key);
  persist(LINK_PLUGIN_KEY, trimmed === 'browser' ? '' : trimmed);
}

/* ── Desktop manager (workspaces + tiling layout) ───────────── */

const DEFAULT_DESKTOP_LAYOUT = {
  mode: 'master',        // 'master' (shown as "Tiling") | 'columns' | 'windows'
  master_ratio: 0.414,   // master fraction (0.25–0.85)
  orientation: 'left',   // 'left' | 'right' | 'top' | 'bottom'
  gap: 4,                // px between windows
  stack_weights: {},     // pluginName -> size of its stack track (relative)
};

function readJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (raw == null) return fallback;
    return JSON.parse(raw);
  } catch (_) {
    return fallback;
  }
}

/** Ordered workspace list: [{ id, windows: [pluginName] }]. */
export function getWorkspaces() {
  if (!getRemember()) return null; // fresh mode: never restore saved windows
  const ws = readJson(scopedKey(DESKTOP_WORKSPACES_KEY), null);
  return Array.isArray(ws) ? ws : null;
}

export function setWorkspaces(workspaces) {
  if (!getRemember()) return; // fresh mode: don't persist the desktop
  const raw = JSON.stringify(workspaces);
  localStorage.setItem(scopedKey(DESKTOP_WORKSPACES_KEY), raw);
  persist(DESKTOP_WORKSPACES_KEY, raw);
}

export function getActiveWorkspaceId() {
  if (!getRemember()) return null;
  return localStorage.getItem(scopedKey(DESKTOP_ACTIVE_KEY)) || null;
}

export function setActiveWorkspaceId(id) {
  if (!getRemember()) return;
  const key = scopedKey(DESKTOP_ACTIVE_KEY);
  if (id) localStorage.setItem(key, id);
  else localStorage.removeItem(key);
  persist(DESKTOP_ACTIVE_KEY, id || '');
}

/**
 * Plugins in focus mode. Deliberately NOT part of a workspace: focus is a
 * working set ("what I am dealing with right now"), not a place on screen, and
 * the AI has to know about it whichever workspace happens to be up. Reading
 * returns [] in fresh mode, like the rest of the desktop state.
 */
export function getPluginFocus() {
  if (!getRemember()) return [];
  const raw = readJson(scopedKey(DESKTOP_FOCUS_KEY), null);
  if (!Array.isArray(raw)) return [];
  return raw.filter((n) => typeof n === 'string' && n);
}

export function setPluginFocus(names) {
  if (!getRemember()) return; // fresh mode: keep the desktop out of storage
  const raw = JSON.stringify([...new Set(names || [])]);
  localStorage.setItem(scopedKey(DESKTOP_FOCUS_KEY), raw);
  persist(DESKTOP_FOCUS_KEY, raw);
}

/** Tiling layout config, merged over defaults. */
export function getDesktopLayout() {
  const stored = readJson(scopedKey(DESKTOP_LAYOUT_KEY), {});
  const out = { ...DEFAULT_DESKTOP_LAYOUT, ...(stored || {}) };
  out.mode = ['master', 'columns', 'windows'].includes(out.mode) ? out.mode : 'master';
  out.master_ratio = clamp(Number(out.master_ratio) || DEFAULT_DESKTOP_LAYOUT.master_ratio, 0.25, 0.85);
  out.orientation = ['left', 'right', 'top', 'bottom'].includes(out.orientation)
    ? out.orientation : DEFAULT_DESKTOP_LAYOUT.orientation;
  out.gap = Math.round(clamp(Number(out.gap) ?? DEFAULT_DESKTOP_LAYOUT.gap, 0, 40));
  const sw = out.stack_weights;
  out.stack_weights = (sw && typeof sw === 'object' && !Array.isArray(sw)) ? { ...sw } : {};
  // A vertical, phone-like screen has no room for a master/stack split or for
  // floating windows, so it always reads as a column — the stored choice is
  // left alone and comes back with the screen.
  if (isMobilePortrait()) out.mode = 'columns';
  return out;
}

export function setDesktopLayout(layout) {
  const raw = JSON.stringify(layout);
  localStorage.setItem(scopedKey(DESKTOP_LAYOUT_KEY), raw);
  persist(DESKTOP_LAYOUT_KEY, raw);
  applyDesktopGap();
}

/**
 * Publish the layout gap to CSS as `--desktop-gap`. The gap is the desktop's
 * one breathing-room value: it separates tiled windows, frames the top bar
 * (its margins plus the space to the workspace switcher) and holds the window
 * edges off the screen. Written onto <html> so a slider drag re-frames
 * everything without a re-render.
 */
export function applyDesktopGap() {
  document.documentElement.style.setProperty('--desktop-gap', `${getDesktopLayout().gap}px`);
}

/**
 * Floating-window geometry (Windows layout mode): pluginName -> { x, y, w, h, z }.
 * Positions are stored in pixels relative to the tile grid and are only used
 * when the desktop layout is 'windows'.
 */
export function getWindowsGeom() {
  const stored = readJson(scopedKey(DESKTOP_WINDOWS_KEY), {});
  return (stored && typeof stored === 'object' && !Array.isArray(stored)) ? stored : {};
}

export function setWindowsGeom(geom) {
  const raw = JSON.stringify(geom || {});
  localStorage.setItem(scopedKey(DESKTOP_WINDOWS_KEY), raw);
  persist(DESKTOP_WINDOWS_KEY, raw);
}

/* ── Granular desktop surface (window chrome) ─────────────────
 * Fine-grained control over how every plugin window looks and feels.
 * Applied as CSS custom properties on <html> so both the desktop shell and
 * the settings page (live preview) share the same source of truth.
 * ───────────────────────────────────────────────────────────── */

const DEFAULT_DESKTOP_SURFACE = {
  window_radius: 17,     // px corner radius (matches --radius-lg default)
  window_opacity: 86,    // % window background opacity
  window_shadow: false,  // flat by default (noir hairline aesthetic)
  glass_blur: 24,        // px backdrop blur: window transparency + frosted panels
  // The ambient "blurred mirror" behind a window (photo / PDF page / artwork /
  // accent glow — web/ui/components/glow.js + .tile-glow in tiles.css). Global,
  // so plugins keep calling setTileGlow*() and core decides whether it shows.
  window_background: false,
  title_height: 36,      // px window title bar height
};

function numOr(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

/** Window-surface settings merged over defaults, each field clamped. */
export function getDesktopSurface() {
  const stored = readJson(scopedKey(DESKTOP_SURFACE_KEY), {});
  const src = (stored && typeof stored === 'object' && !Array.isArray(stored)) ? stored : {};
  return {
    window_radius: Math.round(clamp(numOr(src.window_radius, DEFAULT_DESKTOP_SURFACE.window_radius), 0, 32)),
    window_opacity: Math.round(clamp(numOr(src.window_opacity, DEFAULT_DESKTOP_SURFACE.window_opacity), 60, 100)),
    window_shadow: src.window_shadow === true,
    glass_blur: Math.round(clamp(numOr(src.glass_blur, DEFAULT_DESKTOP_SURFACE.glass_blur), 0, 24)),
    window_background: src.window_background === undefined
      ? DEFAULT_DESKTOP_SURFACE.window_background
      : src.window_background !== false,
    title_height: Math.round(clamp(numOr(src.title_height, DEFAULT_DESKTOP_SURFACE.title_height), 28, 48)),
  };
}

export function setDesktopSurface(patch) {
  const merged = { ...getDesktopSurface(), ...patch };
  const raw = JSON.stringify(merged);
  localStorage.setItem(scopedKey(DESKTOP_SURFACE_KEY), raw);
  persist(DESKTOP_SURFACE_KEY, raw);
  applyDesktopSurface();
}

/** Write the surface settings onto :root as CSS custom properties. */
export function applyDesktopSurface() {
  const s = getDesktopSurface();
  const root = document.documentElement;
  root.style.setProperty('--window-radius', `${s.window_radius}px`);
  root.style.setProperty('--window-opacity', `${s.window_opacity}%`);
  root.style.setProperty('--window-shadow', s.window_shadow ? 'var(--shadow-glass)' : 'none');
  // "Glass blur" drives the backdrop blur of everything frosted: the desktop
  // seen through a translucent window, plugin chrome, and the shared
  // panels/sheets/menus. Writing the base token (not just `-panel`) is what
  // makes the slider do something — themes otherwise own `--glass-blur` and
  // the setting only reached `--glass-blur-panel`. A user value overrides the
  // theme's. `--glass-blur-light` (light scrims) and `--popover-blur` (deliber-
  // ately independent, so menus stay frosted even at 0) keep their theme tuning.
  const blur = `${s.glass_blur}px`;
  root.style.setProperty('--glass-blur', blur);
  root.style.setProperty('--glass-blur-panel', blur);
  // A translucent window gets a backdrop blur (tiles.css); an opaque one does
  // not, so the common case costs no compositing pass.
  root.dataset.windowTranslucent = s.window_opacity < 100 ? '1' : '0';
  // Ambient window background. Off => a data attribute on <html> lets CSS hide
  // the `.tile-glow` layer globally (plugins keep painting it; nothing shows).
  root.dataset.windowBackground = s.window_background ? '1' : '0';
  root.style.setProperty('--tile-header-height', `${s.title_height}px`);
}

/* ── Fullscreen immersion (autohide + bar position) ───────────
 * While a window is fullscreen the desktop chrome steps aside. These
 * preferences decide what steps aside, and from which edge the top bar comes
 * back: the top bar and the voice bar are independent, so the voice bar can
 * stay up while the bar hides (or nothing hides at all).
 * ───────────────────────────────────────────────────────────── */

const IMMERSIVE_KEY = 'desktop.immersive';

/** Where the fullscreen top bar docks and slides in from. */
export const BAR_POSITIONS = ['top', 'left', 'right', 'bottom', 'center'];

/**
 * Where the voice bar is: `top-left` rides the top bar's row at its start (at
 * the rail's height and rounding) and follows the bar to whichever edge it
 * docks to; the bottom variants dock it to that corner of the bottom edge on
 * its own, where the width and height settings apply.
 */
export const ORB_POSITIONS = ['bottom-center', 'bottom-left', 'bottom-right', 'top-left'];

/** The one position that rides the top bar instead of holding an edge alone. */
export const ORB_ATTACHED = 'top-left';

const DEFAULT_IMMERSIVE = {
  autohide_bar: false,
  bar_position: 'bottom',
  autohide_orb: false,
  orb_position: 'top-left',
  /** Width and height of the bar on its own edge. Riding the top bar it takes
   *  the rail's size instead, so these apply on the free dock only. */
  orb_width: 64,
  orb_height: 24,
  orb_color: 'accent',
  /** The bar's own look: `accent` — the body is the accent (or the palette) —
   *  or `bar`, the top bar's glass plate, leaving the accent to the audio glow. */
  orb_style: 'bar',
  /** Border of the bar: none, the accent hairline, or the palette ring. */
  orb_border: 'palette',
  /** What the bar wears: `off`, the humanised tool step line as `text`, or
   *  the running tool's `icons` (swapped per tool with a short fade). */
  orb_status: 'icons',
};

const ORB_COLORS = ['accent', 'palette'];
const ORB_STYLES = ['accent', 'bar'];
const ORB_STATUSES = ['off', 'text', 'icons'];
const ORB_BORDERS = ['none', 'hairline', 'palette'];

/** Fullscreen chrome behaviour, merged over defaults. */
export function getImmersive() {
  const stored = readJson(scopedKey(IMMERSIVE_KEY), {});
  const src = (stored && typeof stored === 'object' && !Array.isArray(stored)) ? stored : {};
  const width = Number(src.orb_width);
  const height = Number(src.orb_height);
  const d = DEFAULT_IMMERSIVE;
  return {
    autohide_bar: src.autohide_bar === undefined ? d.autohide_bar : src.autohide_bar !== false,
    bar_position: BAR_POSITIONS.includes(src.bar_position) ? src.bar_position : d.bar_position,
    autohide_orb: src.autohide_orb === undefined ? d.autohide_orb : src.autohide_orb !== false,
    orb_position: ORB_POSITIONS.includes(src.orb_position) ? src.orb_position : d.orb_position,
    orb_width: Number.isFinite(width) ? Math.round(clamp(width, 64, 400)) : d.orb_width,
    orb_height: Number.isFinite(height) ? Math.round(clamp(height, 24, 72)) : d.orb_height,
    orb_color: ORB_COLORS.includes(src.orb_color) ? src.orb_color : d.orb_color,
    orb_style: ORB_STYLES.includes(src.orb_style) ? src.orb_style : d.orb_style,
    orb_border: ORB_BORDERS.includes(src.orb_border) ? src.orb_border : d.orb_border,
    // `orb_step` (the retired on/off switch) still reads as the text mode.
    orb_status: ORB_STATUSES.includes(src.orb_status)
      ? src.orb_status
      : (src.orb_step === true ? 'text' : d.orb_status),
  };
}

/**
 * Where the voice bar is actually rendered, given both choices.
 *
 * One edge cannot hold both bars: with the top bar docked at the bottom, a
 * bottom-docked voice bar would land on top of it, so it rides the bar's row
 * instead — and a row at the bottom carries it down there with the bar. The
 * stored preference is untouched, so moving the top bar back restores the
 * choice.
 */
export function effectiveOrbPosition(immersive = getImmersive()) {
  if (immersive.bar_position === 'bottom' && immersive.orb_position.startsWith('bottom')) {
    return ORB_ATTACHED;
  }
  return immersive.orb_position;
}

/** Whether the voice bar rides the top bar's row (rather than holding its own edge). */
export function orbIsAttached(immersive = getImmersive()) {
  return effectiveOrbPosition(immersive) === ORB_ATTACHED;
}

export function setImmersive(patch) {
  const merged = { ...getImmersive(), ...patch };
  const raw = JSON.stringify(merged);
  localStorage.setItem(scopedKey(IMMERSIVE_KEY), raw);
  persist(IMMERSIVE_KEY, raw);
  applyImmersive();
}

/** Publish the immersion settings to CSS and the fullscreen controller. */
export function applyImmersive() {
  const s = getImmersive();
  const root = document.documentElement;
  root.dataset.barPos = s.bar_position;
  root.dataset.orbPos = effectiveOrbPosition(s);
  root.dataset.orbAttached = orbIsAttached(s) ? '1' : '0';
  root.dataset.orbColor = s.orb_color;
  root.dataset.orbBorder = s.orb_border;
  root.dataset.orbStyle = s.orb_style;
  root.dataset.orbStatus = s.orb_status;
  // The size the bar takes on its own edge, for the bar element (sphere.css).
  root.style.setProperty('--voice-bar-width', `${s.orb_width}px`);
  root.style.setProperty('--voice-bar-height', `${s.orb_height}px`);
  root.dataset.autohideBar = s.autohide_bar ? '1' : '0';
  root.dataset.autohideOrb = s.autohide_orb ? '1' : '0';
  window.dispatchEvent(new CustomEvent('desktop:immersive', { detail: s }));
}

/* ── Host status chips (top bar: sound, network, Bluetooth, battery) ────
 * Each top-bar chip shows an icon plus, optionally, a device label and a
 * number (volume / signal / battery). These two switches decide which text
 * parts are visible; hiding both leaves an icon-only button. Applied as data
 * attributes on <html> so the stylesheet can hide the spans without the chip
 * modules re-rendering.
 * ───────────────────────────────────────────────────────────── */

const HUD_CHIPS_KEY = 'hud.chips';

/** Which parts of the host status chips are visible, merged over defaults. */
export function getHudChips() {
  return normalizeHudChips(readJson(scopedKey(HUD_CHIPS_KEY), DEFAULT_HUD_CHIPS));
}

export function setHudChips(patch) {
  const merged = normalizeHudChips({ ...getHudChips(), ...patch });
  const raw = JSON.stringify(merged);
  localStorage.setItem(scopedKey(HUD_CHIPS_KEY), raw);
  persist(HUD_CHIPS_KEY, raw);
  applyHudChips();
}

/** Publish the chip visibility to CSS via data attributes on <html>. */
export function applyHudChips() {
  const ds = hudChipsDataset(getHudChips());
  const root = document.documentElement;
  root.dataset.hudName = ds.hudName;
  root.dataset.hudPercent = ds.hudPercent;
}

/* ── Clipboard history (per-user, server-backed) ─────────────
 * The central clipboard service (web/js/clipboard.js) owns the rules; this
 * is only its storage. The entries are small ({ text, source, at } rows,
 * capped by clipboardShared.js), so a preference value is enough — no table.
 * ───────────────────────────────────────────────────────────── */

const CLIPBOARD_HISTORY_KEY = 'clipboard.history';

/** The recorded clipboard entries, newest first (malformed value → empty). */
export function getClipboardHistory() {
  return readJson(scopedKey(CLIPBOARD_HISTORY_KEY), []);
}

export function setClipboardHistory(list) {
  const raw = JSON.stringify(Array.isArray(list) ? list : []);
  localStorage.setItem(scopedKey(CLIPBOARD_HISTORY_KEY), raw);
  persist(CLIPBOARD_HISTORY_KEY, raw);
}

/* ── Voice (per-user, server-backed) ───────────────────────── */

/** The preference key that holds `engine`'s voice. */
function ttsVoiceKey(engine) {
  return engine === 'qwen' ? VOICE_QWEN_VOICE_KEY : VOICE_TTS_VOICE_KEY;
}

/**
 * The stored TTS voice for `engine` (default: the engine in force right now),
 * or '' for "engine default".
 *
 * The two engines' voice sets are disjoint, so a value that does not belong to
 * `engine` — a Qwen speaker stored before the voice was kept per engine, or
 * the pick of an engine Power Saver has swapped away from — is ignored here
 * rather than sent to a server that would answer with a 400.
 */
export function getTtsVoice(engine = getEffectiveTtsEngine()) {
  const stored = localStorage.getItem(scopedKey(ttsVoiceKey(engine)));
  // Voices shared one key (`voice.tts_voice`) before the engines were split, so
  // a speaker picked back then still lives there — for a Qwen user that is a
  // Qwen speaker sitting under the Supertonic key, which this engine's lookup
  // would miss and silently answer in the default voice instead. Fall back to
  // that value; `voiceForEngine` validates it against this engine's own list,
  // so a leftover pick can never reach an engine it does not belong to.
  const legacy = engine === 'qwen' ? localStorage.getItem(scopedKey(VOICE_TTS_VOICE_KEY)) : null;
  return voiceForEngine(engine, stored) || voiceForEngine(engine, legacy);
}

export function setTtsVoice(voice, engine = getEffectiveTtsEngine()) {
  const base = ttsVoiceKey(engine);
  const value = voiceForEngine(engine, voice);
  const key = scopedKey(base);
  if (value) localStorage.setItem(key, value);
  else localStorage.removeItem(key);
  persist(base, value);
}

export function getTtsSpeed() {
  const n = Number(localStorage.getItem(scopedKey(VOICE_TTS_SPEED_KEY)));
  return Number.isFinite(n) && n > 0 ? clamp(n, 0.7, 2.0) : 1.0;
}

export function setTtsSpeed(speed) {
  const n = clamp(numOr(speed, 1.0), 0.7, 2.0);
  localStorage.setItem(scopedKey(VOICE_TTS_SPEED_KEY), String(n));
  persist(VOICE_TTS_SPEED_KEY, String(n));
}

/**
 * Which engine speaks the assistant's replies.
 *
 *   'supertonic' — bundled, small, always available (the default).
 *   'qwen'       — Qwen3-TTS via qwentts.cpp: newer and more natural, and the
 *                  only engine with a Vulkan backend (so an AMD/Intel GPU is
 *                  usable). Opt-in because it needs a one-time build and a
 *                  ~600 MB model download.
 */
export function getTtsEngine() {
  return localStorage.getItem(scopedKey(VOICE_TTS_ENGINE_KEY)) === 'qwen' ? 'qwen' : 'supertonic';
}

export function setTtsEngine(engine) {
  const value = engine === 'qwen' ? 'qwen' : 'supertonic';
  const key = scopedKey(VOICE_TTS_ENGINE_KEY);
  if (value === 'supertonic') localStorage.removeItem(key); // default is implicit
  else localStorage.setItem(key, value);
  persist(VOICE_TTS_ENGINE_KEY, value === 'supertonic' ? '' : value);
}

/**
 * Qwen3-TTS model size. `0.6b-customvoice` is the bundled default;
 * `1.7b-customvoice` is a ~1.2 GB opt-in download.
 */
export function getQwenModel() {
  return localStorage.getItem(scopedKey(VOICE_QWEN_MODEL_KEY)) === '1.7b-customvoice'
    ? '1.7b-customvoice'
    : '0.6b-customvoice';
}

export function setQwenModel(model) {
  const value = model === '1.7b-customvoice' ? '1.7b-customvoice' : '0.6b-customvoice';
  const key = scopedKey(VOICE_QWEN_MODEL_KEY);
  if (value === '0.6b-customvoice') localStorage.removeItem(key);
  else localStorage.setItem(key, value);
  persist(VOICE_QWEN_MODEL_KEY, value === '0.6b-customvoice' ? '' : value);
}

/**
 * Which local model family renders the assistant's images:
 * 'z-image' (default) or 'qwen-image-2.1'. The same key is read server-side
 * from `user_preferences`, so the generate_image tool renders with the model
 * chosen here unless the request names one explicitly.
 */
export function getImageModel() {
  const v = localStorage.getItem(scopedKey(IMAGE_MODEL_KEY));
  return ['z-image', 'qwen-image-2.1'].includes(v) ? v : 'z-image';
}

export function setImageModel(model) {
  const value = ['z-image', 'qwen-image-2.1'].includes(model) ? model : 'z-image';
  const key = scopedKey(IMAGE_MODEL_KEY);
  if (value === 'z-image') localStorage.removeItem(key); // default is implicit
  else localStorage.setItem(key, value);
  persist(IMAGE_MODEL_KEY, value);
}

/**
 * Quality tier for the assistant's local image generation:
 * 'fast' (Q3_K, default) | 'balanced' (Q4_K) | 'high' (Q6_K) | 'max' (Q8_0).
 * The same key is read server-side from `user_preferences`, so the
 * generate_image tool renders at the tier chosen here. Both model families
 * share the tier names.
 */
export function getImageQuality() {
  const v = localStorage.getItem(scopedKey(IMAGE_QUALITY_KEY));
  return ['fast', 'balanced', 'high', 'max'].includes(v) ? v : 'fast';
}

export function setImageQuality(quality) {
  const value = ['fast', 'balanced', 'high', 'max'].includes(quality) ? quality : 'fast';
  const key = scopedKey(IMAGE_QUALITY_KEY);
  if (value === 'fast') localStorage.removeItem(key); // default is implicit
  else localStorage.setItem(key, value);
  persist(IMAGE_QUALITY_KEY, value);
}

/**
 * Quality tier for the assistant's local song generation:
 * 'q4' (Q4_K_M-imat, default) | 'q8' (Q8_0). The same key is read
 * server-side from `user_preferences`, so the generate_song tool renders at
 * the tier chosen here unless the request names one explicitly.
 */
export function getSongQuality() {
  const v = localStorage.getItem(scopedKey(MUSIC_QUALITY_KEY));
  return ['q4', 'q8'].includes(v) ? v : 'q4';
}

export function setSongQuality(quality) {
  const value = ['q4', 'q8'].includes(quality) ? quality : 'q4';
  const key = scopedKey(MUSIC_QUALITY_KEY);
  if (value === 'q4') localStorage.removeItem(key); // default is implicit
  else localStorage.setItem(key, value);
  persist(MUSIC_QUALITY_KEY, value);
}

export function getSilenceTimeout() {
  const n = Number(localStorage.getItem(scopedKey(VOICE_SILENCE_KEY)));
  return Number.isFinite(n) && n >= 3000 ? Math.round(clamp(n, 3000, 30000)) : 8000;
}

export function setSilenceTimeout(ms) {
  const n = Math.round(clamp(numOr(ms, 8000), 3000, 30000));
  localStorage.setItem(scopedKey(VOICE_SILENCE_KEY), String(n));
  persist(VOICE_SILENCE_KEY, String(n));
}

export function getWakeWord() {
  return localStorage.getItem(scopedKey(VOICE_WAKE_KEY)) !== 'false';
}

export function setWakeWord(on) {
  const key = scopedKey(VOICE_WAKE_KEY);
  if (on) localStorage.removeItem(key); // default true
  else localStorage.setItem(key, 'false');
  persist(VOICE_WAKE_KEY, on ? 'true' : 'false');
}

/* ── Conversation window (per-user, server-backed) ────────────
 * Once the wake word has been heard, the assistant stays in conversation: it
 * keeps listening after each answer so a follow-up needs no phrase. On by
 * default — that is what "wake it up and talk to it" means — and it ends on a
 * gesture (a double tap = one thing only, a tap = type) or a stop phrase, not on
 * a timer unless the user picks one. */

export function getConversation() {
  return localStorage.getItem(scopedKey(VOICE_CONVERSATION_KEY)) !== 'false';
}

export function setConversation(on) {
  const key = scopedKey(VOICE_CONVERSATION_KEY);
  if (on) localStorage.removeItem(key); // default true
  else localStorage.setItem(key, 'false');
  persist(VOICE_CONVERSATION_KEY, on ? 'true' : 'false');
}

/**
 * How long the conversation stays open after a reply, in milliseconds.
 * `0` — the default — means "until the user stops it".
 */
export function getConversationTimeout() {
  const raw = localStorage.getItem(scopedKey(VOICE_CONVERSATION_TIMEOUT_KEY));
  if (raw === null) return 0;
  const n = Number(raw);
  return Number.isFinite(n) && n >= 0 ? Math.round(clamp(n, 0, 60000)) : 0;
}

export function setConversationTimeout(ms) {
  const n = Math.round(clamp(numOr(ms, 0), 0, 60000));
  localStorage.setItem(scopedKey(VOICE_CONVERSATION_TIMEOUT_KEY), String(n));
  persist(VOICE_CONVERSATION_TIMEOUT_KEY, String(n));
}

/* ── Speech recognition engine (per-user, server-backed) ──── */

/** Which STT engine voice input uses: 'whisper' (default) or 'vosk'. */
export function getSttEngine() {
  return localStorage.getItem(scopedKey(VOICE_STT_ENGINE_KEY)) === 'vosk' ? 'vosk' : 'whisper';
}

export function setSttEngine(engine) {
  const value = engine === 'vosk' ? 'vosk' : 'whisper';
  const key = scopedKey(VOICE_STT_ENGINE_KEY);
  if (value === 'whisper') localStorage.removeItem(key); // default is implicit
  else localStorage.setItem(key, value);
  persist(VOICE_STT_ENGINE_KEY, value === 'whisper' ? '' : value);
}

/**
 * faster-whisper model size. `tiny` is bundled with the app; `small` is a
 * ~480 MB opt-in download.
 */
export function getWhisperModel() {
  return localStorage.getItem(scopedKey(VOICE_WHISPER_MODEL_KEY)) === 'small' ? 'small' : 'tiny';
}

export function setWhisperModel(model) {
  const value = model === 'small' ? 'small' : 'tiny';
  const key = scopedKey(VOICE_WHISPER_MODEL_KEY);
  if (value === 'tiny') localStorage.removeItem(key);
  else localStorage.setItem(key, value);
  persist(VOICE_WHISPER_MODEL_KEY, value === 'tiny' ? '' : value);
}

/* ── Power management (per-user, server-backed) ──────────────
 * A stored mode, an automatic-power-saver switch and a "Low power AI" switch.
 * The *effective* mode also depends on the live battery status, which the
 * battery chip feeds in with `setPowerBatteryStatus()`. Whenever the effective
 * mode changes, `power:changed` fires so voice.js can re-resolve its engines.
 * ─────────────────────────────────────────────────────────────── */

const POWER_MODE_KEY = 'power.mode';
const POWER_AUTO_SAVER_KEY = 'power.auto_saver';
const POWER_LOW_AI_KEY = 'power.low_power_ai';

let powerBatteryStatus = null;
let effectivePowerModeCache = null;

/** The chosen power mode: 'performance', 'balanced' (default) or 'saver'. */
export function getPowerMode() {
  return normalizePowerMode(localStorage.getItem(scopedKey(POWER_MODE_KEY)));
}

export function setPowerMode(mode) {
  const value = normalizePowerMode(mode);
  const key = scopedKey(POWER_MODE_KEY);
  if (value === 'balanced') localStorage.removeItem(key); // default is implicit
  else localStorage.setItem(key, value);
  persist(POWER_MODE_KEY, value === 'balanced' ? '' : value);
  recomputeEffectivePowerMode();
  announcePowerSettings();
}

/** Whether Balanced drops to Power Saver on battery / low charge. Default on. */
export function getAutoPowerSaver() {
  return localStorage.getItem(scopedKey(POWER_AUTO_SAVER_KEY)) !== 'false';
}

export function setAutoPowerSaver(on) {
  const key = scopedKey(POWER_AUTO_SAVER_KEY);
  if (on) localStorage.removeItem(key); // default true
  else localStorage.setItem(key, 'false');
  persist(POWER_AUTO_SAVER_KEY, on ? 'true' : 'false');
  recomputeEffectivePowerMode();
  announcePowerSettings();
}

/**
 * Whether Power Saver switches the AI to lighter engines (Vosk + Supertonic).
 * On by default — the whole point of the saver for a voice-first app.
 */
export function getLowPowerAi() {
  return localStorage.getItem(scopedKey(POWER_LOW_AI_KEY)) !== 'false';
}

export function setLowPowerAi(on) {
  const key = scopedKey(POWER_LOW_AI_KEY);
  if (on) localStorage.removeItem(key); // default true
  else localStorage.setItem(key, 'false');
  persist(POWER_LOW_AI_KEY, on ? 'true' : 'false');
  recomputeEffectivePowerMode();
  announcePowerSettings();
}

/** The mode actually in force, from the stored mode + battery status. */
export function getEffectivePowerMode() {
  if (effectivePowerModeCache == null) recomputeEffectivePowerMode();
  return effectivePowerModeCache || 'balanced';
}

/**
 * Feed the latest battery snapshot in (from the battery chip). Recomputes the
 * effective mode and announces a change on `power:changed`.
 */
export function setPowerBatteryStatus(status) {
  powerBatteryStatus = status || null;
  recomputeEffectivePowerMode();
  announcePowerSettings();
}

/** Tell open power surfaces (menu, Settings) that a stored value changed. */
function announcePowerSettings() {
  if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
    window.dispatchEvent(new Event('power:settings'));
  }
}

/** The last battery snapshot fed in by the battery chip (may be null). */
export function getPowerBatteryStatus() {
  return powerBatteryStatus;
}

function recomputeEffectivePowerMode() {
  const next = effectivePowerMode(getPowerMode(), getAutoPowerSaver(), powerBatteryStatus);
  if (next === effectivePowerModeCache) return;
  effectivePowerModeCache = next;
  if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
    window.dispatchEvent(new CustomEvent('power:changed', { detail: { mode: next } }));
  }
}

/** True when Power Saver is in force and it is allowed to switch engines. */
export function isLowPowerAiActive() {
  return getEffectivePowerMode() === 'saver' && getLowPowerAi();
}

/**
 * The STT engine voice input should use right now. Low-power AI overrides the
 * Voice setting with Vosk without overwriting it — leaving the saver restores
 * the user's own choice.
 */
export function getEffectiveSttEngine() {
  return isLowPowerAiActive() ? 'vosk' : getSttEngine();
}

/** The TTS engine replies should use right now. Low-power AI forces Supertonic. */
export function getEffectiveTtsEngine() {
  return isLowPowerAiActive() ? 'supertonic' : getTtsEngine();
}

/* ── Touch Bar (per-user, server-backed) ───────────────────── */

/**
 * Whether Touch Bar input is honoured: `auto` (follow the host's detection),
 * `on` (force it, useful to try the buttons on a normal keyboard) or `off`.
 */
export function getTouchBarEnabled() {
  return normalizeTouchBarSetting(localStorage.getItem(scopedKey(TOUCHBAR_KEY)));
}

export function setTouchBarEnabled(mode) {
  const value = normalizeTouchBarSetting(mode);
  const key = scopedKey(TOUCHBAR_KEY);
  if (value === 'auto') localStorage.removeItem(key); // default is implicit
  else localStorage.setItem(key, value);
  persist(TOUCHBAR_KEY, value === 'auto' ? '' : value);
  // The runtime listens for this so a change applies without a reload.
  window.dispatchEvent(new CustomEvent('touchbar:settings'));
}

/* ── Interface language (per-user, server-backed) ──────────────
 * The value itself lives in i18n.js (it has to be readable before any other
 * module boots, and applied without one); this is only its persistence:
 * `''` means "automatic" (follow the system language).
 * ─────────────────────────────────────────────────────────────── */

/** The chosen interface language, or '' when following the system language. */
export function getUiLocale() {
  return getLocalePreference();
}

export function setUiLocale(code) {
  const value = (code || '').trim();
  setLocalePreference(value);
  persist(UI_LOCALE_KEY, value);
}

function clamp(n, min, max) {
  return Math.min(max, Math.max(min, n));
}

/* ── Iroh remote access ───────────────────────────────────────── */

const REMOTE_ALLOW_TERMINAL_KEY = 'remote.allow_terminal';

/**
 * Whether a remote (Iroh) client may open the Terminal — a real shell on this
 * machine. Off by default; the server enforces this.
 */
export function getRemoteAllowTerminal() {
  return localStorage.getItem(scopedKey(REMOTE_ALLOW_TERMINAL_KEY)) === 'true';
}

export function setRemoteAllowTerminal(on) {
  const key = scopedKey(REMOTE_ALLOW_TERMINAL_KEY);
  if (on) localStorage.setItem(key, 'true');
  else localStorage.removeItem(key);
  persist(REMOTE_ALLOW_TERMINAL_KEY, on ? 'true' : '');
}

/* ── Early surface application ─────────────────────────────────
 * `loadUserPreferences()` (which calls applyDesktopSurface()) only runs after
 * auth resolves, but the desktop can have already painted by then. Apply the
 * last session's cached surface and layout gap now so a translucent/blurred
 * window, a disabled ambient background and the desktop's frame are correct
 * from the first frame; the stored server values simply re-apply the same
 * result a moment later.
 * ─────────────────────────────────────────────────────────────── */
if (typeof document !== 'undefined') {
  applyDesktopSurface();
  applyDesktopGap();
}
