/**
 * Shiny UI — unified component library.
 *
 * Theme-agnostic engine. Structure lives in /ui/ui.css; every visual
 * decision comes from the active theme in /themes/<name>/. Plugin
 * content (artifacts, insights) is rendered through these components,
 * so plugins always match the user's theme and accent.
 */

export { initThemeLoader, listThemes, setTheme, getActiveTheme, getThemeManifest, themeMode, themeUrl } from './theme-loader.js';
export {
  initIconLoader, iconsetOptions, getIconsetChoice, getActiveIconset,
  setIconset, loadSetIndex, setHas, paletteFor, tintEnabled, setTint,
} from './iconset-loader.js';
export {
  initAppearance, refreshAppearance, applyAppearance,
  getAccent, setAccent, getGradient, setGradient,
  accentPresets, gradientPresets, gradientToCss,
  getFont, setFont, applyFont, fontStackFor, FONT_THEME,
  hexToRgb, rgba, contrastFor, cssVar,
} from './appearance.js';
export { icon, setIcon, clearIconCache, hydrateIcons, loadIconSvg, refreshIcons, refreshFolderIcons, colorizeFolder, tintSvg, decorateSvg } from './icon.js';
export { reveal } from './reveal.js';
export { transition, disposeMotion, revealRegion, enterSurface, reducedMotion, motionDuration } from './motion.js';
export { controlGrid, controlCard, controlGroup, toolbar } from './components/layout.js';
export { segmented } from './components/choice.js';

export { button, iconButton, controlButton, toolButton, menuButton } from './components/button.js';
export { element } from './components/element.js';
export { placePopover, placeMenu } from './popover.js';
export { field, input, textarea, select, selectControl, useSelectMenu, toggle, toggleRow, slider, checkbox, searchBar } from './components/field.js';
export { card, panel, section, divider, stack, row } from './components/card.js';
export { modal, floating, sheet, tooltip } from './components/overlay.js';
export { toast, wireToastEvents, spinner, skeleton, progress, emptyState, badge } from './components/feedback.js';
export { notify, wireNotificationEvents } from './components/notifications.js';
export { list, listItem, stat, chip, avatar, keyValue } from './components/data.js';
export {
  dockButton, insightCard, artifactPanel,
  iconForArtifact, labelForArtifact,
} from './components/composites.js';
export {
  installGlow, refreshGlow, glowFor, createRim, setGlow, setTileGlow,
  setTileGlowFromUrl, glowUrl, glowGradient, glowFromDrawable, glowFromImageUrl, partnerColor,
} from './components/glow.js';

export { dial } from './components/dial.js';
export { mediaCard } from './components/media.js';
export { confirmDialog, promptDialog } from './components/dialog.js';
export { menuSurface, menuItem } from './components/menu.js';
