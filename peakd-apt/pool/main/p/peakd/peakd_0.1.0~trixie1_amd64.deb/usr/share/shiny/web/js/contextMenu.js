import { controlButton } from '../ui/components/button.js';
/**
 * contextMenu.js — right-click context menus for the core desktop.
 *
 * The desktop is a Hyprland-style window manager (desktop.js + tiles.js), so
 * right-click follows the same conventions as a real WM:
 *
 *   • Right-click anywhere in a plugin window (title bar OR content) → window
 *     menu (focus mode / bring to front / fullscreen / move-to-workspace / the
 *     app's own actions / close window / deactivate).
 *   • Right-click in a text field (anywhere in the app) → edit menu (cut /
 *     copy / paste / select all).
 *   • Right-click a plugin tray icon in the top bar → plugin menu (focus mode,
 *     bring to front, fullscreen, open window when it was closed, activate /
 *     deactivate).
 *   • Right-click the top bar itself        → desktop menu.
 *   • Right-click the empty desktop         → desktop menu (new / remove
 *     workspace, switch workspace, layout mode).
 *   • Right-click a workspace dot           → workspace menu (new / remove).
 *   • Right-click the voice bar              → assistant menu (new chat, chat
 *     history, type a message, thinking on/off, close chat, voice, settings).
 *
 * Any other right-click inside the shell is swallowed: it must never reach
 * QtWebEngine, whose native Back/Forward/Reload menu has no place in the app.
 * A right-click inside a Browser-plugin page opens this same menu over the
 * page (the shell forwards the request; plugins/browser/web/plugin.js).
 *
 * On a touchscreen a long press opens the same menus (there is no right
 * button). The voice bar and the virtual keyboard keep their own press-and-hold, so
 * they opt out.
 *
 * Apps extend their own window menu by exporting `contextMenu(ctx)` from their
 * `web/plugin.js` surface (see PLUGINS.md §19); anything they return is spliced
 * into the window menu. A plugin may also call `openContextMenu()` for fully
 * custom popups.
 *
 * The menu itself is a small, self-contained popup engine: `openMenu` takes a
 * list of entries (items, separators, headings, and one level of submenus) and
 * renders a body-level popup reusing the app's glass tokens and `hudMenuIn`
 * animation. All desktop state is read fresh from desktop.js at open time.
 */
import {
  createWorkspace, removeWorkspace, switchWorkspace, focusWindow,
  moveWindow, moveWindowByIndex, getWorkspacesList,
  activeWorkspaceIndex, getLayout, setLayout, getFocus, getFullscreen,
  workspacesEnabled, workspaceLock, workspaceLabel,
  isPluginFocused, togglePluginFocus,
} from './desktop.js';
import { toggleWindowFullscreen } from './fullscreen.js';
import {
  deactivatePlugin, activatePlugin, getPluginSurface, getPluginTile,
  isCoreWindow, closeCoreWindow, openCoreWindow, closePluginWindow,
} from './tiles.js';
import { refreshGpsPosition } from './map.js';
import { setIcon, toast } from '../ui/index.js';
import { newChat, stopActiveTurn, isTurnActive } from './agent.js';
import { openChatHistory } from './chatHistory.js';
import { openTextInput, closeChat, isTextInputOpen } from './textInput.js';
import { startListening, cancelListening, isListening } from './voice.js';
import { getSphereState, waitForVoiceReady } from './sphere.js';
import { readClipboardText } from './clipboard.js';
import { getAiName, getWakeWord, setWakeWord, getThink, setThink } from './preferences.js';
import { canThink } from './thinkToggle.js';
import { notifyMenuChange } from './menuState.js';
import { t } from './i18n.js';

/* ── Popup engine ─────────────────────────────────────────────── */

const MENU_CLS = 'ctx-menu';
const PAD = 8;

/** Open menu elements, outermost first. Submenus are appended on top. */
const menuStack = [];
let globalWired = false;

function wireGlobal() {
  if (globalWired) return;
  globalWired = true;
  document.addEventListener('pointerdown', onGlobalPointerDown, true);
  document.addEventListener('keydown', onGlobalKeyDown, true);
  window.addEventListener('blur', closeAllMenus);
  window.addEventListener('resize', closeAllMenus);
  window.addEventListener('scroll', onGlobalScroll, true);
  // A keyboard/AI-driven workspace switch (or a fullscreen toggle) moves the
  // ground under an open menu; close it rather than leaving it stale.
  window.addEventListener('desktop:changed', closeAllMenus);
}

function unwireGlobal() {
  if (!globalWired) return;
  globalWired = false;
  document.removeEventListener('pointerdown', onGlobalPointerDown, true);
  document.removeEventListener('keydown', onGlobalKeyDown, true);
  window.removeEventListener('blur', closeAllMenus);
  window.removeEventListener('resize', closeAllMenus);
  window.removeEventListener('scroll', onGlobalScroll, true);
  window.removeEventListener('desktop:changed', closeAllMenus);
}

/** A scroll elsewhere invalidates the menu's anchor; a scroll inside the menu
 *  itself (long menus scroll) must not dismiss it. */
function onGlobalScroll(e) {
  if (!e.target?.closest?.(`.${MENU_CLS}`)) closeAllMenus();
}

function onGlobalPointerDown(e) {
  if (!menuStack.length) return;
  // A press outside any open menu dismisses it (but still passes through, so
  // e.g. clicking a tile also raises the window).
  if (!menuStack.some((m) => m.contains(e.target))) closeAllMenus();
}

function onGlobalKeyDown(e) {
  if (!menuStack.length) return;
  if (e.key === 'Escape') {
    e.preventDefault();
    e.stopPropagation();
    closeAllMenus();
  }
}

function pushMenu(el) {
  menuStack.push(el);
  if (menuStack.length === 1) wireGlobal();
  notifyMenuChange();
}

function closeFrom(el) {
  const i = menuStack.indexOf(el);
  if (i < 0) return;
  const closing = menuStack.splice(i);
  closing.forEach((m) => m.remove());
  if (!menuStack.length) unwireGlobal();
  notifyMenuChange();
}

export function closeAllMenus() {
  const closing = menuStack.splice(0);
  closing.forEach((m) => m.remove());
  unwireGlobal();
  notifyMenuChange();
}

/** Position a just-appended menu at (x, y), clamped inside the viewport. */
function place(el, x, y) {
  const w = el.offsetWidth;
  const h = el.offsetHeight;
  const left = Math.max(PAD, Math.min(x, window.innerWidth - w - PAD));
  const top = Math.max(PAD, Math.min(y, window.innerHeight - h - PAD));
  el.style.left = `${left}px`;
  el.style.top = `${top}px`;
}

/** Open a root menu with the given entries at (x, y). */
function openMenu(entries, x, y) {
  const el = buildMenu(entries);
  document.body.appendChild(el);
  place(el, x, y);
  pushMenu(el);
  return el;
}

/**
 * Public entry point for plugin surfaces: open a core-styled context menu at
 * (x, y) with the same entry shape the desktop menus use.
 *
 *   openContextMenu([
 *     { type: 'heading', label: 'Cell' },
 *     { type: 'item', label: 'Clear', icon: 'ui/close', onClick: () => … },
 *   ], e.clientX, e.clientY);
 */
export function openContextMenu(entries, x, y) {
  closeAllMenus();
  return openMenu(entries, x, y);
}

/** Text-like fields get the edit menu; a `<select>` is a picker, not a field. */
function isTextField(el) {
  if (!el) return false;
  if (el.tagName === 'TEXTAREA') return true;
  if (el.tagName === 'INPUT') {
    const type = (el.getAttribute('type') || 'text').toLowerCase();
    return ['text', 'password', 'email', 'search', 'number', 'tel', 'url'].includes(type);
  }
  return el.isContentEditable === true;
}

/** The current selection inside a field, for the edit menu's enable state. */
function fieldSelection(el) {
  if (typeof el.selectionStart === 'number' && typeof el.selectionEnd === 'number') {
    return String(el.value ?? '').slice(el.selectionStart, el.selectionEnd);
  }
  const selection = window.getSelection?.();
  return selection && el.contains(selection.anchorNode) ? selection.toString() : '';
}

/**
 * Edit menu for a text field: cut / copy / paste / select all, in the app's
 * own styling. The DOM commands keep the clipboard service in play (it
 * captures the copy/cut events and records them), and paste reads the service
 * so anything copied inside the app can be pasted back even where the async
 * Clipboard API is unavailable.
 */
function editMenu(target) {
  const selection = fieldSelection(target);
  const locked = target.disabled === true || target.readOnly === true;
  const focusTarget = () => target.focus({ preventScroll: true });
  return [
    {
      type: 'item',
      label: t('common.cut'),
      disabled: locked || !selection,
      onClick: () => {
        focusTarget();
        document.execCommand('cut');
      },
    },
    {
      type: 'item',
      label: t('common.copy'),
      icon: 'ui/copy',
      disabled: !selection,
      onClick: () => {
        focusTarget();
        document.execCommand('copy');
      },
    },
    {
      type: 'item',
      label: t('common.paste'),
      icon: 'ui/clipboard',
      disabled: locked,
      onClick: async () => {
        const text = await readClipboardText();
        if (!text) return;
        focusTarget();
        document.execCommand('insertText', false, text);
      },
    },
    { type: 'separator' },
    {
      type: 'item',
      label: t('common.selectAll'),
      icon: 'ui/select-all',
      onClick: () => {
        focusTarget();
        if (typeof target.select === 'function') {
          target.select();
          return;
        }
        const range = document.createRange();
        range.selectNodeContents(target);
        const selectionNow = window.getSelection?.();
        if (selectionNow) {
          selectionNow.removeAllRanges();
          selectionNow.addRange(range);
        }
      },
    },
  ];
}

/** Entries an app contributes to its own window menu. A plugin's surface
 *  module may export `contextMenu(ctx)` returning core menu entries; a throw
 *  becomes "no extra items" so a buggy plugin can never break right-click. */
function pluginMenuItems(name, ctx) {
  const surface = getPluginSurface(name);
  if (typeof surface?.contextMenu !== 'function') return [];
  try {
    const items = surface.contextMenu(ctx);
    return Array.isArray(items) ? items.filter(Boolean) : [];
  } catch (err) {
    console.warn(`contextMenu() for '${name}' failed`, err);
    return [];
  }
}

/** Shared row scaffold: [check] [icon] [label] (+ chevron for submenus). */
function rowShell(text, danger) {
  const item = controlButton();
  item.type = 'button';
  item.className = MENU_CLS + '-item';
  if (danger) item.classList.add('is-danger');
  item.setAttribute('role', 'menuitem');
  // Pressing a row must not blur what is behind the menu: the edit actions
  // work on the target field's own focus and selection.
  item.addEventListener('pointerdown', (e) => e.preventDefault());

  const check = document.createElement('span');
  check.className = 'ctx-menu-check';
  const ic = document.createElement('span');
  ic.className = 'ctx-menu-icon';
  const lab = document.createElement('span');
  lab.className = 'ctx-menu-label';
  lab.textContent = text;
  item.append(check, ic, lab);
  return { item, check, ic, lab };
}

function buildItem(entry) {
  const { item, check, ic } = rowShell(entry.label, entry.danger);
  if (entry.checked) {
    item.classList.add('is-active');
    void setIcon(check, 'ui/check', { size: 14 });
  }
  if (entry.icon) void setIcon(ic, entry.icon, { size: 14 });
  if (entry.disabled) item.disabled = true;

  item.addEventListener('click', () => {
    if (entry.disabled) return;
    closeAllMenus();
    entry.onClick?.();
  });
  return item;
}

/** Submenus are limited to one level — the desktop never needs deeper. */
function buildSubmenuItem(entry, parentEl) {
  const { item, check, ic } = rowShell(entry.label, entry.danger);
  if (entry.checked) item.classList.add('is-active');
  if (entry.icon) void setIcon(ic, entry.icon, { size: 14 });

  const chev = document.createElement('span');
  chev.className = 'ctx-menu-chevron';
  void setIcon(chev, 'ui/chevron-right', { size: 14 });
  item.appendChild(chev);

  let subEl = null;

  const openSub = () => {
    // Already open (and still attached)? Nothing to do.
    if (subEl && subEl.isConnected) return;
    // Close any other open submenu of this menu first, and drop stale
    // bookkeeping: after a submenu was closed elsewhere, the old `subEl`
    // reference stayed set and silently blocked reopening it.
    if (parentEl.__openSub) {
      if (parentEl.__openSub.isConnected) closeFrom(parentEl.__openSub);
      parentEl.__openSub = null;
    }

    subEl = buildMenu(entry.items);
    document.body.appendChild(subEl);
    const r = item.getBoundingClientRect();
    placeSub(subEl, r);
    pushMenu(subEl);
    parentEl.__openSub = subEl;
  };

  item.addEventListener('pointerenter', openSub);
  item.addEventListener('click', (e) => {
    e.stopPropagation();
    openSub();
  });

  return item;
}

function placeSub(subEl, anchor) {
  const w = subEl.offsetWidth;
  const h = subEl.offsetHeight;
  let left = anchor.right + 4;
  if (left + w > window.innerWidth - PAD) left = anchor.left - w - 4;
  let top = anchor.top;
  if (top + h > window.innerHeight - PAD) top = window.innerHeight - h - PAD;
  subEl.style.left = `${Math.max(PAD, left)}px`;
  subEl.style.top = `${Math.max(PAD, top)}px`;
}

function buildMenu(entries) {
  const el = document.createElement('div');
  el.className = MENU_CLS;
  el.setAttribute('role', 'menu');
  // Suppress the native context menu over our own popup.
  el.addEventListener('contextmenu', (e) => e.preventDefault());

  for (const entry of entries) {
    if (!entry) continue;
    if (entry.type === 'separator') {
      const sep = document.createElement('div');
      sep.className = 'ctx-menu-sep';
      el.appendChild(sep);
    } else if (entry.type === 'heading') {
      const h = document.createElement('div');
      h.className = 'ctx-menu-heading';
      h.textContent = entry.label;
      el.appendChild(h);
    } else if (entry.type === 'submenu') {
      el.appendChild(buildSubmenuItem(entry, el));
    } else {
      el.appendChild(buildItem(entry));
    }
  }
  return el;
}

/* ── Menu definitions ─────────────────────────────────────────── */

function label(name) {
  return name ? name.charAt(0).toUpperCase() + name.slice(1) : name;
}

function moveToWorkspaceItems(name) {
  if (!workspacesEnabled()) return [];
  const items = [];
  getWorkspacesList().forEach((ws, i) => {
    // A fullscreen app owns its workspace: nothing else can be moved in.
    const locked = workspaceLock(ws);
    if (locked) {
      items.push({
        type: 'item',
        label: t('ctx.workspaceFullScreen', { name: workspaceLabel(ws) }),
        disabled: true,
      });
      return;
    }
    items.push({
      type: 'item',
      label: workspaceLabel(ws),
      checked: ws.windows.includes(name),
      onClick: () => moveWindow(name, ws.id),
    });
  });
  items.push({ type: 'separator' });
  items.push({
    type: 'item',
    label: t('ctx.newWorkspace'),
    icon: 'ui/plus',
    onClick: () => moveWindowByIndex(name, 'new'),
  });
  return items;
}

/** The traveler window is core-hosted (the map), not a plugin surface, so its
 *  app entries are supplied here rather than by `contextMenu()`. */
function travelerMenuItems() {
  return [
    {
      type: 'item',
      label: t('ctx.centerOnPosition'),
      icon: 'ui/pin',
      onClick: () => void refreshGpsPosition(),
    },
  ];
}

/** Window menu: window management + whatever the app contributes. */
function windowMenu(name, ctx = {}) {
  const app = name === 'traveler' ? travelerMenuItems() : pluginMenuItems(name, ctx);
  // A fullscreen app is pinned to its workspace for as long as it is
  // fullscreen, so the move submenu is off rather than misleading.
  const isFull = getFullscreen() === name;
  const moveItem = isFull
    ? {
      type: 'item',
      label: t('ctx.moveToWorkspace'),
      icon: 'ui/grid',
      disabled: true,
    }
    : {
      type: 'submenu',
      label: t('ctx.moveToWorkspace'),
      icon: 'ui/grid',
      items: moveToWorkspaceItems(name),
    };
  return [
    { type: 'heading', label: label(name) },
    {
      type: 'item',
      label: t('ctx.focusPlugin'),
      icon: 'ui/eye',
      checked: isPluginFocused(name),
      onClick: () => {
        togglePluginFocus(name);
        // Reveal it too: focusing a window that is on another workspace must
        // not be an invisible state change.
        window.dispatchEvent(new CustomEvent('plugin:focus', { detail: { name } }));
      },
    },
    {
      type: 'item',
      label: t('ctx.bringToFront'),
      icon: 'ui/monitor',
      checked: getFocus() === name,
      onClick: () => focusWindow(name),
    },
    {
      type: 'item',
      label: isFull ? t('ctx.exitFullscreen') : t('ctx.fullscreen'),
      icon: 'ui/expand',
      checked: isFull,
      onClick: () => toggleWindowFullscreen(name),
    },
    { type: 'separator' },
    moveItem,
    ...(app.length ? [{ type: 'separator' }, ...app] : []),
    { type: 'separator' },
    ...(isCoreWindow(name)
      ? [{
        type: 'item',
        label: t('common.close'),
        icon: 'ui/close',
        danger: true,
        onClick: () => closeCoreWindow(name),
      }]
      : [
        {
          // Closing the window leaves the plugin enabled — its tools stay
          // available and the tray can bring the window back. Deactivate is the
          // separate, persistent switch.
          type: 'item',
          label: t('common.close'),
          icon: 'ui/close',
          onClick: () => closePluginWindow(name),
        },
        {
          type: 'item',
          label: t('ctx.deactivate'),
          icon: 'ui/close',
          danger: true,
          onClick: () => void deactivatePlugin(name),
        },
      ]),
  ];
}

/** Top-bar plugin tray icon → plugin menu. Lifecycle only: the app's own
 *  actions live in its window menu. */
function trayMenu(btn) {
  const name = btn?.dataset?.plugin;
  if (!name) return null;
  const active = btn.classList.contains('is-active');
  const hasWindow = !!getPluginTile(name);

  const items = [{ type: 'heading', label: label(name) }];
  if (active) {
    if (hasWindow) {
      items.push({
        type: 'item',
        label: isPluginFocused(name) ? t('ctx.unfocusPlugin') : t('ctx.focusPlugin'),
        icon: 'ui/eye',
        checked: isPluginFocused(name),
        onClick: () => {
          togglePluginFocus(name);
          window.dispatchEvent(new CustomEvent('plugin:focus', { detail: { name } }));
        },
      });
      items.push({
        type: 'item',
        label: t('ctx.bringToFront'),
        icon: 'ui/monitor',
        onClick: () => window.dispatchEvent(new CustomEvent('plugin:focus', { detail: { name } })),
      });
      items.push({
        type: 'item',
        label: getFullscreen() === name ? t('ctx.exitFullscreen') : t('ctx.fullscreen'),
        icon: 'ui/expand',
        checked: getFullscreen() === name,
        onClick: () => toggleWindowFullscreen(name),
      });
    } else {
      // The plugin is on but its window was closed: reopen it. This is the
      // counterpart of close ≠ deactivate.
      items.push({
        type: 'item',
        label: t('ctx.openWindow', null, 'Open window'),
        icon: 'ui/expand',
        onClick: () => window.dispatchEvent(new CustomEvent('plugin:focus', { detail: { name } })),
      });
    }
    items.push({ type: 'separator' });
    items.push({
      type: 'item',
      label: t('ctx.deactivate'),
      icon: 'ui/close',
      danger: true,
      onClick: () => void deactivatePlugin(name),
    });
  } else {
    items.push({
      type: 'item',
      label: t('ctx.activate'),
      icon: 'ui/plus',
      onClick: () => void activatePlugin(name),
    });
  }
  return items;
}

function switchWorkspaceItems() {
  return getWorkspacesList().map((ws, i) => ({
    type: 'item',
    label: workspaceLabel(ws),
    checked: i === activeWorkspaceIndex(),
    onClick: () => switchWorkspace(i),
  }));
}

/** The way out of a fullscreen app, offered wherever the desktop is clicked. */
function exitFullscreenItem() {
  const fs = getFullscreen();
  if (!fs) return [];
  return [{
    type: 'item',
    label: t('ctx.exitFullscreenFor', { name: label(fs) }),
    icon: 'ui/expand',
    onClick: () => toggleWindowFullscreen(fs),
  }];
}

function layoutItems() {
  const mode = getLayout().mode;
  return [
    { type: 'item', label: t('ctx.layoutColumns'), checked: mode === 'columns', onClick: () => setLayout({ mode: 'columns' }) },
    { type: 'item', label: t('ctx.layoutTiling'), checked: mode === 'master', onClick: () => setLayout({ mode: 'master' }) },
    { type: 'item', label: t('ctx.layoutWindows'), checked: mode === 'windows', onClick: () => setLayout({ mode: 'windows' }) },
  ];
}

function desktopMenu() {
  const layout = { type: 'submenu', label: t('ctx.layout'), icon: 'ui/arranger', items: layoutItems() };
  const exitFs = exitFullscreenItem();
  // A vertical screen is one column and one workspace, so the switcher has
  // nothing to offer — the layout menu is all that is left.
  if (!workspacesEnabled()) {
    return [{ type: 'heading', label: t('ctx.desktop') }, ...exitFs, layout];
  }
  const wss = getWorkspacesList();
  return [
    { type: 'heading', label: t('ctx.desktop') },
    ...exitFs,
    ...(exitFs.length ? [{ type: 'separator' }] : []),
    { type: 'item', label: t('ctx.newWorkspace'), icon: 'ui/plus', onClick: () => createWorkspace() },
    {
      type: 'item',
      label: t('ctx.removeWorkspace'),
      icon: 'ui/minus',
      disabled: wss.length <= 1,
      onClick: () => removeWorkspace(),
    },
    { type: 'separator' },
    { type: 'submenu', label: t('ctx.switchToWorkspace'), icon: 'ui/grid', items: switchWorkspaceItems() },
    layout,
  ];
}

function workspaceDotMenu(index) {
  const wss = getWorkspacesList();
  const ws = wss[index];
  return [
    { type: 'heading', label: workspaceLabel(ws) || t('ctx.workspaceNumber', { n: index + 1 }) },
    ...exitFullscreenItem(),
    { type: 'item', label: t('ctx.newWorkspace'), icon: 'ui/plus', onClick: () => createWorkspace() },
    {
      type: 'item',
      label: t('ctx.removeWorkspace'),
      icon: 'ui/minus',
      disabled: wss.length <= 1,
      onClick: () => {
        // removeWorkspace() removes the ACTIVE workspace — switch to the
        // right-clicked one first so the dot's own workspace is removed.
        if (index !== activeWorkspaceIndex()) switchWorkspace(index);
        removeWorkspace();
      },
    },
  ];
}

/* ── The voice bar ────────────────────────────────────────────── */

/** Start a single listen from the voice bar's menu. A menu click is a real user
 *  gesture, so the microphone request is allowed to run. */
async function orbListen() {
  if (isListening()) return;
  const sphere = document.getElementById('sphere-container');
  if (sphere?.classList.contains('disabled')) {
    // A menu click during the cold-login warm-up is held like a tap on the bar:
    // listen as soon as the recognizer is ready.
    if (getSphereState() !== 'warming') {
      toast(t('ctx.voiceUnavailable'), { type: 'info' });
      return;
    }
    toast(t('ctx.voiceWarming'), { type: 'info' });
    if (!(await waitForVoiceReady())) {
      toast(t('ctx.voiceStillWarming'), { type: 'info' });
      return;
    }
    if (isListening()) return;
  }
  if (isTurnActive()) await stopActiveTurn('menu');
  try {
    await startListening('single');
  } catch (e) {
    toast(e.message || t('ctx.microphoneUnavailable'), { type: 'error' });
  }
}

/** Right-click / long-press on the voice bar: the assistant and voice actions. */
function orbMenu() {
  return [
    { type: 'heading', label: getAiName() },
    {
      type: 'item',
      label: t('chat.newChat'),
      icon: 'ui/plus',
      onClick: () => {
        newChat();
        toast(t('ctx.chatStarted'), { type: 'info' });
      },
    },
    { type: 'item', label: t('chat.history'), icon: 'ui/list', onClick: () => openChatHistory() },
    { type: 'item', label: t('chat.typeMessage'), icon: 'ui/message-circle', onClick: () => openTextInput() },
    {
      // The brain toggle: same switch (and same glyphs) as the chat head.
      type: 'item',
      label: canThink() ? t('chat.thinking') : t('chat.thinkingUnavailable'),
      icon: getThink() && canThink() ? 'ui/brain' : 'ui/brain-off',
      checked: getThink(),
      disabled: !canThink(),
      onClick: () => setThink(!getThink()),
    },
    {
      type: 'item',
      label: t('chat.close'),
      icon: 'ui/close',
      disabled: !isTextInputOpen(),
      onClick: () => closeChat(),
    },
    { type: 'separator' },
    {
      type: 'submenu',
      label: t('voice.label'),
      icon: 'ui/mic',
      items: [
        {
          type: 'item',
          label: t('ctx.listenNow'),
          icon: 'ui/mic',
          disabled: isListening(),
          onClick: () => void orbListen(),
        },
        {
          type: 'item',
          label: t('ctx.stopListening'),
          icon: 'ui/stop',
          disabled: !isListening(),
          onClick: () => cancelListening(),
        },
        { type: 'separator' },
        {
          type: 'item',
          label: t('ctx.wakeWord'),
          icon: 'ui/mic',
          checked: getWakeWord(),
          onClick: () => setWakeWord(!getWakeWord()),
        },
      ],
    },
    { type: 'separator' },
    { type: 'item', label: t('hud.settings'), icon: 'ui/settings', onClick: () => openCoreWindow('settings') },
  ];
}

/* ── Long-press → context menu (touch) ────────────────────────── */

const LONG_PRESS_MS = 450;      // a touch held this long opens the menu
const LONG_PRESS_MOVE = 12;     // px of travel that turns the gesture into a scroll

/**
 * Targets that keep their own press-and-hold: the voice bar already owns the
 * long press (it starts voice), the virtual keyboard repeats a held key, and a
 * press-and-hold inside a text field is the platform's own text selection.
 */
const LONG_PRESS_EXCLUDE = [
  '#sphere-container',
  '#keyboard-bar',
  `.${MENU_CLS}`,
  'input',
  'textarea',
  'select',
  '[contenteditable="true"]',
  '[data-no-longpress]',
].join(',');

/**
 * Translate a touch long-press into a `contextmenu` event on the pressed
 * element, so every desktop menu is reachable on a touchscreen. Mouse input is
 * ignored (it has a right button) and anything that owns the gesture opts out.
 */
function wireLongPress() {
  if (document.__longPressWired) return;
  document.__longPressWired = true;

  let timer = null;
  let node = null;
  let x = 0;
  let y = 0;
  // A long press must not also fire the element's click action when the finger
  // lifts; swallow that click. It is cleared on the next pointerdown, so the
  // tap that picks a menu item is never swallowed.
  let swallowClick = false;

  const cancel = () => {
    if (timer) clearTimeout(timer);
    timer = null;
    node = null;
  };

  document.addEventListener('click', (e) => {
    if (!swallowClick) return;
    swallowClick = false;
    e.preventDefault();
    e.stopPropagation();
  }, { capture: true });

  document.addEventListener('pointerdown', (e) => {
    swallowClick = false;
    if (e.pointerType === 'mouse' || e.button !== 0) return;
    if (e.target?.closest?.(LONG_PRESS_EXCLUDE)) return;
    node = e.target;
    x = e.clientX;
    y = e.clientY;
    timer = setTimeout(() => {
      timer = null;
      let target = node;
      node = null;
      if (!target || !target.isConnected) target = document.elementFromPoint(x, y);
      if (!target) return;
      swallowClick = true;
      target.dispatchEvent(new MouseEvent('contextmenu', {
        bubbles: true,
        cancelable: true,
        composed: true,
        button: 2,
        clientX: x,
        clientY: y,
      }));
    }, LONG_PRESS_MS);
  }, { capture: true, passive: true });

  document.addEventListener('pointermove', (e) => {
    if (!timer) return;
    if (Math.hypot(e.clientX - x, e.clientY - y) > LONG_PRESS_MOVE) cancel();
  }, { capture: true, passive: true });

  document.addEventListener('pointerup', cancel, { capture: true, passive: true });
  document.addEventListener('pointercancel', cancel, { capture: true, passive: true });
}

/* ── Wiring ───────────────────────────────────────────────────── */

export function initContextMenu() {
  const app = document.getElementById('app');
  if (!app || app.__ctxMenuWired) return;
  app.__ctxMenuWired = true;

  app.addEventListener('contextmenu', (e) => {
    const target = e.target;

    // Text fields → the edit menu. The shell draws every menu itself; the
    // native Qt editing menu is gone (its entries were dead in the app view
    // anyway — only a child page view could serve them).
    if (isTextField(target)) {
      e.preventDefault();
      closeAllMenus();
      openMenu(editMenu(target), e.clientX, e.clientY);
      return;
    }

    // Plugin tray icon (top bar) → plugin lifecycle menu.
    const tray = target.closest?.('.hud-plugin-btn');
    if (tray) {
      const entries = trayMenu(tray);
      if (!entries) return;
      e.preventDefault();
      closeAllMenus();
      openMenu(entries, e.clientX, e.clientY);
      return;
    }

    // The voice bar → assistant / voice menu.
    if (target.closest?.('#sphere-container')) {
      e.preventDefault();
      closeAllMenus();
      openMenu(orbMenu(), e.clientX, e.clientY);
      return;
    }

    // Anywhere in a plugin window — title bar OR content — → window menu,
    // extended with the app's own entries (surface `contextMenu()`).
    const tile = target.closest?.('.tile');
    if (tile) {
      const name = tile.dataset.plugin;
      if (!name) return;
      e.preventDefault();
      closeAllMenus();
      openMenu(
        windowMenu(name, { plugin: name, tile, target, source: 'window' }),
        e.clientX,
        e.clientY,
      );
      return;
    }

    // Workspace dot → workspace menu.
    const dot = target.closest?.('.workspace-bar-dot');
    if (dot) {
      // The dot's order in the bar is the workspace index; a fullscreen-app
      // dot shows an icon and has no number to parse.
      const index = Array.prototype.indexOf.call(dot.parentElement?.children || [], dot);
      if (index < 0) return;
      e.preventDefault();
      closeAllMenus();
      openMenu(workspaceDotMenu(index), e.clientX, e.clientY);
      return;
    }

    // Top bar background (the HUD pill / workspace bar / fullscreen bubble)
    // → desktop menu. The bubble's own buttons keep their click behaviour.
    if (
      target.closest?.('.hud-header-main')
      || target.closest?.('#workspace-bar')
      || target.closest?.('#fullscreen-bubble')
    ) {
      e.preventDefault();
      closeAllMenus();
      openMenu(desktopMenu(), e.clientX, e.clientY);
      return;
    }

    // Empty desktop only — #app itself is the hit target because the tile
    // grid is pointer-events:none and every other layer is chrome with its
    // own pointer-events.
    if (target === app) {
      e.preventDefault();
      closeAllMenus();
      openMenu(desktopMenu(), e.clientX, e.clientY);
      return;
    }

    // Anything else in the shell: swallow it, never show a menu. An unhandled
    // contextmenu event is what used to raise QtWebEngine's own
    // Back/Forward/Reload menu over the app — chat compose, overlays, modals,
    // an open HUD popover, the tile overlay.
    e.preventDefault();
  });

  // Touchscreens have no right button: a long press opens the same menus.
  wireLongPress();
}
