import { getTraveler } from './api.js';
import { requireAuth } from './auth.js';
import { initMap, getCurrentPosition } from './map.js';
import {
  initSphere, setSphereState, onShortTap, onLongPressStart, onLongPressEnd,
  onDoubleTap, setConversationMode, setMicLevel, resetMicLevel,
  getSphereState, waitForVoiceReady,
} from './sphere.js';
import { prepareVoice, startListening, cancelListening, isListening, releaseWakeHold, isWakeAwaitingCommand, markCorrectionPending, leaveConversation, isConversationOpen } from './voice.js';
import { sendToAgent, sendToAgentCompose, stopActiveTurn, isTurnActive } from './agent.js';
import { startGpsTracking, stopGpsTracking } from './gps.js';
import {
  initThemeLoader, initIconLoader, initAppearance, refreshAppearance,
  wireToastEvents, wireNotificationEvents, toast, hydrateIcons, reveal,
} from '../ui/index.js';
import { refreshActivePlugins, resetSessionPlugins } from './activePlugins.js';
import { initArtifactDock } from './artifacts.js';
import { initInsightCards } from './insights/insightCards.js';
import { initHudClock, initHudTrips } from './hudLeft.js';
import { initClockMenu } from './clockMenu.js';
import { initWeatherMenu } from './weatherMenu.js';
import { initHudNetwork } from './hudNetwork.js';
import { initHudAudio } from './hudAudio.js';
import { initHudBluetooth } from './hudBluetooth.js';
import { initHudBattery } from './hudBattery.js';
import { initHudPower } from './powerMenu.js';
import { initHudDividers } from './hudDivider.js';
import { initHudPlugins, openPlugin } from './hudPlugins.js';
import { initPluginHud } from './pluginHud.js';
import { initCraftStore } from './craftStore.js';
import { initAppFileEvents } from './appSaves.js';
import { installClipboard } from './clipboard.js';
import { initHudClipboard } from './clipboardMenu.js';
import { initNavigator } from './navigator.js';
import { initTileManager, openCoreWindow, getPluginTile } from './tiles.js';
import { initFullscreen } from './fullscreen.js';
import { initFullscreenBubble } from './fullscreenBubble.js';
import { initOverview } from './overview.js';
import { initLauncher } from './launcher.js';
import { initGestures } from './gestures.js';
import { initContextMenu } from './contextMenu.js';
import { initLinkRouter } from './linkRouter.js';
import { initKeyboard, refreshKeyboard } from './keyboard.js';
import { initTextInput, openTextInput, isTextInputOpen, isComposeAwaiting } from './textInput.js';
import { initChatHistory } from './chatHistory.js';
import { initThinkToggle } from './thinkToggle.js';
import { initTouchBar } from './touchbar.js';
import { reloadUserSession } from './session.js';
import { loadUserPreferences, getRemember, getWakeWord } from './preferences.js';
import { initI18n } from './i18n.js';
import { initBackground } from './background.js';
import { hideBootScreen } from './bootScreen.js';

let appInitialized = false;
// null = not yet evaluated — the first check must always apply show/hide,
// otherwise a fresh load in bare mode leaves the map stack visible.
let travelerActive = null;
// null = not yet evaluated — the first sync must always apply show/hide, even
// when the map starts closed (a fresh session or a closed remembered window).
let travelerWindowVisible = null;
let lastUserId = null;

function cancelVoiceInput() {
  if (isWakeAwaitingCommand()) return;
  cancelListening();
  setConversationMode(false);
  resetMicLevel();
  setSphereState('idle');
}

async function boot() {
  // The bar's separators come from the one hudDivider factory; mount them
  // before anything awaits so the bar never paints without them.
  initHudDividers();
  // Interface language before anything can render text — the sign-in screen is
  // static markup that showLogin() reveals as-is, so the catalogs have to be
  // in hand before the first reveal (the splash still covers the app here).
  await initI18n();
  // Theme + appearance first: everything renders through these tokens.
  await initThemeLoader();
  initIconLoader(); // resolve the stored icon set against the theme's mode
  initAppearance({ getScope: () => getTraveler()?.id });
  initBackground({ getScope: () => getTraveler()?.id });
  wireToastEvents();
  wireNotificationEvents();
  hydrateIcons();

  window.addEventListener('auth:success', async () => {
    document.getElementById('app')?.classList.remove('hidden');
    hideBootScreen();
    const userId = getTraveler()?.id;
    // A different account just signed in — do a clean boot so no cross-user
    // state (desktop layout, tiling, tiles, artifacts) leaks between accounts.
    if (appInitialized && lastUserId && userId && lastUserId !== userId) {
      window.location.reload();
      return;
    }
    lastUserId = userId;
    if (appInitialized) {
      await reloadUserSession();
      // A sign-in starts a new session. With "remember" off that means the
      // desktop resets here too, not only on a page load: previous activations
      // are dropped and every plugin window closes with them.
      if (!getRemember()) {
        await resetSessionPlugins();
        window.dispatchEvent(new CustomEvent('plugins:changed'));
      }
      refreshAppearance();
      await applyTravelerActivation();
      await refreshKeyboard();
      return;
    }
    await beginSession();
  });

  // Plugins panel may toggle the traveler plugin — re-evaluate and re-render
  // the map / navigator / saved-trips HUD when that happens. The plugins page
  // is separate, so the signal travels via localStorage.
  window.addEventListener('plugins:changed', async () => {
    await applyTravelerActivation();
  });
  window.addEventListener('storage', async (e) => {
    if (e.key === 'plugins.changed') await applyTravelerActivation();
  });
  // The map's chrome and GPS follow the traveler *window*, not the plugin's
  // enabled state: closing the window is a real close even with the plugin on.
  window.addEventListener('windows:changed', () => syncTravelerWindow());

  if (!(await requireAuth())) return;

  document.getElementById('app').classList.remove('hidden');
  hideBootScreen();
  await beginSession();
}

/** Load this user's preferences, then start the desktop. In fresh mode the
 *  previous sign-in's plugin activations are dropped first, so "don't
 *  remember" really means an empty desktop with every plugin closed. */
async function beginSession() {
  await loadUserPreferences();
  if (!getRemember()) await resetSessionPlugins();
  await initApp();
}

async function initApp() {
  if (appInitialized) {
    await reloadUserSession();
    refreshAppearance();
    return;
  }
  appInitialized = true;

  initSphere();
  initArtifactDock();
  initTextInput(submitTextToAgent);
  initChatHistory(); // core chat history panel (new chat / resume old chats)
  initThinkToggle(); // brain button: Ollama thinking on/off, capability-gated
  initHudClock(); // core chrome — works with zero plugins
  initClockMenu(); // clock popover: location time + the calendar month
  initWeatherMenu(); // weather popover: current + the next five days
  initHudAudio(); // host sound chip (PipeWire, Linux)
  initHudNetwork(); // host network status chip (NetworkManager, Linux)
  initHudBluetooth(); // host Bluetooth chip (BlueZ, Linux)
  initHudBattery(); // host battery chip (sysfs power-supply, Linux)
  initHudPower(); // top-bar power menu (reboot / power off / suspend, logind)
  initHudPlugins(); // plugin icon tray in the top bar — works with zero plugins
  initPluginHud(); // optional per-plugin top-bar chips (loaded when installed)
  initCraftStore(); // Craft store: keeps the installed Craft apps updated
  // A Craft app saves through the browser APIs inside its iframe: the shell
  // reports the path so the desktop can say where the file went and refresh the
  // folder (the app itself only knows the handle).
  initAppFileEvents({ notify: (message) => toast(message, { type: 'ok' }) });
  // Central clipboard: record every copy app-wide (DOM copy/cut events), expose
  // the hook the Qt shell reports Browser-page copies through, and mount the
  // top-bar history menu. Installed before any plugin window can copy.
  installClipboard();
  initHudClipboard();
  initTileManager(); // plugin window shell — mounts tiles for any active plugin
  // Settings and Plugins are built-in windows now, opened from the HUD.
  document.getElementById('settings-btn')?.addEventListener('click', () => openCoreWindow('settings'));
  document.getElementById('plugins-btn')?.addEventListener('click', () => openCoreWindow('plugins'));
  initFullscreen(); // real fullscreen + edge-revealed chrome for a fullscreen window
  initFullscreenBubble(); // app name + close/exit in a top-bar bubble while fullscreen
  initOverview();    // three-finger swipe up: every open window, live
  initLauncher();    // three-finger swipe down: the plugin launcher
  initGestures();    // the trackpad:gesture vocabulary the peakd shell sends (Linux)
  initContextMenu(); // right-click menus on the desktop / window title bars / workspace dots
  initLinkRouter();  // every link opens in the browser plugin (kiosk only)
  initKeyboard();    // virtual keyboard plugin — bottom bar + HUD toggle

  await applyTravelerActivation();
  await refreshKeyboard();
  await openLiveInstaller();

  setInterval(() => {
    if (!document.hidden) void reloadUserSession();
  }, 60000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) void reloadUserSession();
  });
  await reloadUserSession();
  refreshAppearance();

  prepareVoice();
  wireSphere();
  wireVoiceResults();
  initTouchBar({ talk: tapOrb });
  reveal();
}

/// The live image has exactly one job: open the installer window as soon as
/// the shell is ready. The route exists only when the installer plugin is
/// active in live mode, so an installed system never auto-opens it.
async function openLiveInstaller() {
  try {
    const res = await fetch('/api/installer/health', { cache: 'no-store' });
    if (res.status === 404) return;
    await openPlugin('installer');
  } catch (_) {
    // Normal installed sessions have no installer route.
  }
}

/// Re-evaluate the traveler plugin's enabled state, then sync its window.
async function applyTravelerActivation() {
  const active = await refreshActivePlugins({ force: true });
  const wasActive = travelerActive;
  travelerActive = active.has('traveler');

  // The HUD modules below wire global listeners; run them once per activation
  // transition. Whether the map itself is on screen is a separate state.
  if (travelerActive && !wasActive) {
    initHudTrips();
    initNavigator();
    initInsightCards();
  }
  syncTravelerWindow();
}

/// The OSM map chrome, navigator, saved-trips HUD and GPS follow the traveler
/// *window* being open, not the plugin being enabled: closing the window is a
/// real close, so the map UI and the GPS watch go with it.
function syncTravelerWindow() {
  const visible = !!travelerActive && !!getPluginTile('traveler')?.isConnected;
  if (visible === travelerWindowVisible) return;
  travelerWindowVisible = visible;

  const mapVignette = document.getElementById('map-vignette');
  const navPuck = document.getElementById('nav-puck');
  const hudSavedTrips = document.getElementById('hud-saved-trips');
  const travelPanel = document.getElementById('travel-panel');
  const travelPanelBackdrop = document.getElementById('travel-panel-backdrop');
  const insightCards = document.getElementById('insight-cards');

  const hide = (el) => el?.classList.add('hidden');
  const show = (el) => el?.classList.remove('hidden');

  if (visible) {
    if (!document.getElementById('map')?.childElementCount) {
      void initMap();
    }
    show(mapVignette);
    startGpsTracking();
  } else {
    hide(mapVignette);
    hide(navPuck);
    hide(hudSavedTrips);
    hudSavedTrips?.classList.add('empty');
    hide(travelPanel);
    hide(travelPanelBackdrop);
    hide(insightCards);
    // Chat-only mode: no artifact chrome.
    hide(document.getElementById('artifact-dock'));
    // The GPS watch belongs to the map window — leaving it running drains
    // battery and keeps pinging the location API with no map on screen.
    stopGpsTracking();
  }
}

function voiceReady() {
  return document.getElementById('sphere-container') &&
    !document.getElementById('sphere-container').classList.contains('disabled');
}

/** Voice gestures while the speech model prepares: feedback, not silence. */
function voiceNotReady() {
  const preparing = getSphereState() === 'warming';
  toast(
    preparing
      ? 'Voice is preparing — try again in a moment'
      : 'Voice unavailable — you can still tap to type',
    { type: 'info' },
  );
}

/**
 * The voice bar's listening gesture (double-tap), in one place: the Touch Bar's
 * "Ask" button calls this too, so both paths share the voice-readiness check,
 * the stop-and-rephrase behaviour and the error handling.
 */
async function tapOrb() {
  if (isTextInputOpen() || isComposeAwaiting()) return;
  if (!voiceReady()) {
    // Cold login: the speech model can still be warming up when the first tap
    // arrives. Hold the tap instead of dropping it with a toast — the
    // microphone opens by itself as soon as the recognizer is usable.
    if (getSphereState() !== 'warming') {
      voiceNotReady();
      return;
    }
    toast('Voice is warming up — listening starts when it is ready', { type: 'info' });
    if (!(await waitForVoiceReady())) {
      voiceNotReady();
      return;
    }
    // The wait can be long enough for the user to open the keyboard or start
    // listening some other way; the held tap must not talk over that.
    if (isListening() || isTextInputOpen() || isComposeAwaiting()) return;
  }

  if (isListening()) {
    const inConversation = isConversationOpen();
    cancelVoiceInput();
    // A tap inside a conversation means "one thing only": the mode ends here and
    // the tap opens a single request below, instead of only cancelling.
    if (!inConversation) return;
  }

  // Tapping while the assistant is answering stops it and hands the mic
  // straight over: "stop, let me rephrase". Stopping it means what follows is a
  // correction of that answer, so the next turn is marked as one.
  if (isTurnActive()) {
    markCorrectionPending();
    await stopActiveTurn('tap');
  }

  // Whatever conversation was open ends with this tap — including one that was
  // only waiting for its reply, so the answer cannot re-open a window the user
  // has closed.
  leaveConversation();

  try {
    await startListening('single');
  } catch (e) {
    setSphereState('error');
    toast(e.message || 'Microphone unavailable', { type: 'error' });
    setTimeout(() => setSphereState('idle'), 2000);
  }
}

/** The voice bar's typing gesture (single tap): type to the assistant. */
function typeOrb() {
  if (isComposeAwaiting()) return;
  // Typing takes over from the voice, so a conversation ends here; a plain
  // listening session keeps its old behaviour (the keyboard opens over it).
  if (isConversationOpen()) leaveConversation();
  else if (isListening() && !isWakeAwaitingCommand()) cancelVoiceInput();
  openTextInput();
}

function wireSphere() {
  // A single tap opens the keyboard. Text needs no speech model, so this works
  // even while voice is still preparing (or unavailable).
  onShortTap(typeOrb);

  onLongPressStart(async () => {
    if (isListening() || isComposeAwaiting()) return;
    if (!voiceReady()) {
      voiceNotReady();
      return;
    }
    if (isTurnActive()) {
      markCorrectionPending();
      await stopActiveTurn('long-press');
    }
    try {
      // Long-press is the wake-word gesture; when the wake word is disabled it
      // falls back to a normal single-shot listen.
      await startListening(getWakeWord() ? 'wake' : 'single');
    } catch (e) {
      setConversationMode(false);
      setSphereState('error');
      toast(e.message || 'Microphone unavailable', { type: 'error' });
    }
  });

  // Releasing the voice bar never closes the microphone: the hold only *arms*
  // the wake listener ("hey <name>"), or a single-shot listen when the wake word
  // is off. sphere.js has just flipped the bar to idle on release, so put the
  // reactive conversation look back and let the wake window, the silence
  // timeout or a short tap end the session.
  onLongPressEnd(() => {
    releaseWakeHold();
    if (isListening()) {
      setSphereState('conversation');
      return;
    }
    setConversationMode(false);
    resetMicLevel();
    if (!isTextInputOpen()) setSphereState('idle');
  });

  // Double-tap = listen once, with the same stop-and-rephrase behaviour as the
  // Touch Bar's "Ask" button.
  onDoubleTap(tapOrb);
}

async function submitTextToAgent(text, handlers) {
  const ctx = travelerActive ? getCurrentPosition() : null;
  try {
    await sendToAgentCompose(text, ctx, handlers);
  } catch (_) {}
}

/**
 * Voice barge-in: the user started talking over the assistant.
 *
 * Stop the answer (voice.js already cut the audio; this abandons the turn so
 * the core records the interruption) and open the microphone on the new
 * request, so "wait, I meant…" lands as the next question instead of being
 * talked over.
 */
async function handleBargeIn() {
  stopActiveTurn('barge-in');

  if (isTextInputOpen() || isComposeAwaiting()) return;
  if (isListening() || !voiceReady()) return;

  try {
    await startListening('single');
  } catch (e) {
    setSphereState('error');
    toast(e.message || 'Microphone unavailable', { type: 'error' });
    setTimeout(() => setSphereState('idle'), 2000);
  }
}

function wireVoiceResults() {
  window.addEventListener('voice:result', async (e) => {
    const { text, mode, correction } = e.detail;
    const ctx = travelerActive ? getCurrentPosition() : null;
    const agentMode = mode === 'continuous' ? 'continuous' : 'single';

    setConversationMode(false);
    resetMicLevel();

    try {
      await sendToAgent(text, agentMode, ctx, correction);
    } catch (_) {}

    if (!isTextInputOpen() && !isComposeAwaiting()) setSphereState('idle');
  });

  window.addEventListener('voice:barge-in', () => {
    void handleBargeIn();
  });

  window.addEventListener('voice:level', (e) => {
    setMicLevel(e.detail);
  });
}

boot();
